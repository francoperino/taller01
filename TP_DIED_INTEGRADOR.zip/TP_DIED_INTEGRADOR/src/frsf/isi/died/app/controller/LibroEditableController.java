package frsf.isi.died.app.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import frsf.isi.died.app.dao.MaterialCapacitacionDao;
import frsf.isi.died.app.dao.MaterialCapacitacionDaoDefault;
import frsf.isi.died.app.vista.material.LibroPanel;
import frsf.isi.died.app.vista.material.LibroPanelEditable;
import frsf.isi.died.tp.modelo.productos.Libro;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;
import frsf.isi.died.tp.modelo.productos.Relevancia;

public class LibroEditableController {
	private LibroPanelEditable panelLibro;
	private MaterialCapacitacionDao materialDAO;
	
	public LibroEditableController(LibroPanelEditable panel) {
		this.panelLibro = panel;
		this.panelLibro.setController(this);
		materialDAO = new MaterialCapacitacionDaoDefault();
	}

	public void eliminarLibro(int id) {
		MaterialCapacitacion libroBorrar=materialDAO.findById(id);
		List<MaterialCapacitacion> lista = new ArrayList<MaterialCapacitacion>();
		lista.addAll(materialDAO.listaMateriales());
		lista.remove(libroBorrar);
		try {
			materialDAO.getDataResource().borrarArchivo("libros.csv");
			for(MaterialCapacitacion aux :lista) {
				if(aux.esLibro())
					materialDAO.getDataResource().agregarFilaAlFinal("libros.csv", aux);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		materialDAO.recargarGrafo();		

		this.panelLibro.setListaLibros(materialDAO.listaLibros(),true);
	}
	
	public void actualizarLibro(int id_anterior,String titulo,Double costo,Double precio,Integer paginas,String fecha,Relevancia rel,int calificacion,String tema) {	
		materialDAO.findById(id_anterior).setLibro(titulo, costo, precio, paginas, fecha, rel, calificacion,tema);
		this.panelLibro.setListaLibros(materialDAO.listaLibros(),true);
		try {
			materialDAO.getDataResource().borrarArchivo("libros.csv");
			for(Libro aux :materialDAO.listaLibros()) {
				materialDAO.getDataResource().agregarFilaAlFinal("libros.csv", aux);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void crearPanel() {		
		this.panelLibro.setListaLibros(materialDAO.listaLibros(),false);
		this.panelLibro.construir();
	}

	public LibroPanelEditable getPanelLibro() {
		return panelLibro;
	}

	public void setPanelLibro(LibroPanelEditable panelLibro) {
		this.panelLibro = panelLibro;
	}
	
	

}
