package frsf.isi.died.app.controller;

public class WishlistController {

}
