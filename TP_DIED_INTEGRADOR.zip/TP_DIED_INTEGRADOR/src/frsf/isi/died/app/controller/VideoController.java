package frsf.isi.died.app.controller;

import java.text.ParseException;
import java.util.Date;

import frsf.isi.died.app.dao.MaterialCapacitacionDao;
import frsf.isi.died.app.dao.MaterialCapacitacionDaoDefault;
import frsf.isi.died.app.vista.material.VideoPanel;
import frsf.isi.died.app.vista.material.VideoPanelEditable;
import frsf.isi.died.tp.modelo.productos.Relevancia;
import frsf.isi.died.tp.modelo.productos.Video;

public class VideoController {
	private VideoPanel panelVideo;
	private MaterialCapacitacionDao materialDAO;
	
	public VideoController(Object panel)  {
		this.panelVideo = (VideoPanel)panel;
		this.panelVideo.setController(this);
		materialDAO = new MaterialCapacitacionDaoDefault();
	}
	

	
	public void agregarVideo(int id,String titulo,Double costo,Integer duracion,String fecha,Relevancia rel,int calificacion,String tema) {	
		Video v = new Video(id,titulo, costo, duracion,fecha,rel,calificacion,tema) ;
		materialDAO .agregarVideo(v);
		this.panelVideo.setListaVideos(materialDAO.listaVideos(),true);
	}
	
	public void crearPanel() {		
		this.panelVideo.setListaVideos(materialDAO.listaVideos(),false);
		this.panelVideo.construir();
	}

	public VideoPanel getPanelVideo() {
		return panelVideo;
	}

	public void setPanelVideo(VideoPanel panelVideo) {
		this.panelVideo = panelVideo;
	}

}
