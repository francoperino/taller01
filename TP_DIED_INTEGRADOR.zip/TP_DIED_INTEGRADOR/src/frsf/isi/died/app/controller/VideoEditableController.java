package frsf.isi.died.app.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import frsf.isi.died.app.dao.MaterialCapacitacionDao;
import frsf.isi.died.app.dao.MaterialCapacitacionDaoDefault;
import frsf.isi.died.app.vista.material.VideoPanel;
import frsf.isi.died.app.vista.material.VideoPanelEditable;
import frsf.isi.died.tp.modelo.productos.Libro;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;
import frsf.isi.died.tp.modelo.productos.Relevancia;
import frsf.isi.died.tp.modelo.productos.Video;

public class VideoEditableController {
	private VideoPanelEditable panelVideo;
	private MaterialCapacitacionDao materialDAO;
	
	public VideoEditableController(VideoPanelEditable panel) {
		this.panelVideo = panel;
		this.panelVideo.setController(this);
		materialDAO = new MaterialCapacitacionDaoDefault();
	}
	
	public void eliminarVideo(int id) {
		MaterialCapacitacion videoBorrar=materialDAO.findById(id);
		List<MaterialCapacitacion> lista = new ArrayList<MaterialCapacitacion>();
		lista.addAll(materialDAO.listaMateriales());
		lista.remove(videoBorrar);
		try {
			materialDAO.getDataResource().borrarArchivo("videos.csv");
			for(MaterialCapacitacion aux :lista) {
				if(aux.esVideo())
					materialDAO.getDataResource().agregarFilaAlFinal("videos.csv", aux);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		materialDAO.recargarGrafo();		

		this.panelVideo.setListaVideos(materialDAO.listaVideos(),true);
	}
	
	public void actualizarVideo(int id,String titulo,Double costo,Integer duracion,String fecha,Relevancia rel,int calificacion,String tema) {	
		materialDAO.findById(id).setVideo(titulo, costo, duracion, fecha, rel, calificacion,tema);
		this.panelVideo.setListaVideos(materialDAO.listaVideos(),true);
		try {
			materialDAO.getDataResource().borrarArchivo("videos.csv");
			for(Video aux :materialDAO.listaVideos()) {
				materialDAO.getDataResource().agregarFilaAlFinal("videos.csv", aux);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void crearPanel() {		
		this.panelVideo.setListaVideos(materialDAO.listaVideos(),false);
		this.panelVideo.construir();
	}

	public VideoPanelEditable getPanelVideo() {
		return panelVideo;
	}

	public void setPanelVideo(VideoPanelEditable panelVideo) {
		this.panelVideo = panelVideo;
	}

}
