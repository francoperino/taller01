package frsf.isi.died.app.controller;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import frsf.isi.died.app.dao.MaterialCapacitacionDao;
import frsf.isi.died.app.dao.MaterialCapacitacionDaoDefault;
import frsf.isi.died.app.vista.grafo.AristaView;
import frsf.isi.died.app.vista.grafo.ControlPanel;
import frsf.isi.died.app.vista.grafo.GrafoPanel;
import frsf.isi.died.app.vista.grafo.VerticeView;
import frsf.isi.died.tp.estructuras.Arista;
import frsf.isi.died.tp.estructuras.Grafo;
import frsf.isi.died.tp.estructuras.Vertice;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;

public class GrafoController {

	private GrafoPanel vistaGrafo;
	private ControlPanel vistaControl;
	private MaterialCapacitacionDao materialDao;

	public GrafoController(GrafoPanel panelGrf, ControlPanel panelCtrl) {
		this.vistaGrafo = panelGrf;
		this.vistaGrafo.setController(this);
		this.vistaControl = panelCtrl;
		this.vistaControl.setController(this);
		this.materialDao = new MaterialCapacitacionDaoDefault();
		this.vistaControl.menuOpciones(materialDao.listaMateriales());
		//this.vistaControl.armarPanel(materialDao.listaMateriales());
	}

	public void crearVertice(Integer coordenadaX, Integer coordenadaY, Color color, MaterialCapacitacion mc) {
		VerticeView v = new VerticeView(coordenadaX, coordenadaY, color);
		v.setId(mc.getId());
		v.setNombre(mc.getTitulo());
		this.vistaGrafo.agregar(v);
		this.vistaGrafo.repaint();
		

	}

	public void crearArista(AristaView arista) {
		String temaInicio=this.materialDao.findById(arista.getOrigen().getId()).getTema();
		String temaFin=this.materialDao.findById(arista.getDestino().getId()).getTema();
		if(temaInicio.compareTo(temaFin)==0) {
			this.materialDao.crearCamino(arista.getOrigen().getId(), arista.getDestino().getId());
			this.vistaGrafo.agregar(arista);
			this.vistaGrafo.repaint();
			}
	}

	
	/*public void buscarCamino(Integer nodo1, Integer nodo2, Integer saltos) {
		List<MaterialCapacitacion> camino = this.materialDao.buscarCamino(nodo1, nodo2, saltos);
		this.vistaGrafo.caminoPintar(camino);
		this.vistaGrafo.repaint();
	}*/
	
	public int buscarTodosCaminos(Integer nodo1, Integer nodo2,Integer ubicacion,Integer saltos) {
		List<List<MaterialCapacitacion>>resultado=new ArrayList<List<MaterialCapacitacion>>();
		resultado=this.materialDao.buscarCamino(nodo1, nodo2, saltos);
		if(ubicacion<resultado.size()) {
			List<MaterialCapacitacion> aux=new ArrayList<MaterialCapacitacion>();
			aux.addAll(resultado.get(ubicacion));
			this.vistaGrafo.caminoPintar(aux);
			this.vistaGrafo.repaint();
			return 0;
		}
		else {
			List<MaterialCapacitacion> aux=new ArrayList<MaterialCapacitacion>();
			aux.addAll(resultado.get(0));
			this.vistaGrafo.caminoPintar(aux);
			this.vistaGrafo.repaint();
			return -1;
		}
			
	}

	public List<MaterialCapacitacion> listaVertices() {
		return materialDao.listaMateriales();
	}
	
	public List<MaterialCapacitacion> pageRank(String tema){
		this.materialDao.recargarGrafo();
		List<MaterialCapacitacion> resultado=new ArrayList<MaterialCapacitacion>();
		resultado.addAll(this.materialDao.calcularPageRank(tema));
		Collections.sort(resultado, new Comparator<MaterialCapacitacion>() {
	        @Override
			public int compare(MaterialCapacitacion arg0, MaterialCapacitacion arg1) {
				// TODO Auto-generated method stub
	        	return (Double.compare(arg0.getPagerankNew(), arg1.getPagerankNew()))*-1;
				
			}
	    });
		return resultado; 
	}
	
}
