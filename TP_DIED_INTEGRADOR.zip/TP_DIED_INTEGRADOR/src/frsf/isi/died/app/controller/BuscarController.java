package frsf.isi.died.app.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import frsf.isi.died.app.dao.MaterialCapacitacionDao;
import frsf.isi.died.app.dao.MaterialCapacitacionDaoDefault;
import frsf.isi.died.app.vista.material.BusquedaMaterialPanel;
import frsf.isi.died.tp.modelo.BibliotecaABB;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;

public class BuscarController {

	private BusquedaMaterialPanel panelBusqueda;
	private MaterialCapacitacionDao materialDAO;

	public BuscarController(Object panel){
		this.panelBusqueda = (BusquedaMaterialPanel)panel;
		this.panelBusqueda.setController(this);
		materialDAO = new MaterialCapacitacionDaoDefault();
	}
	
	public void crearPanel() {		
		this.panelBusqueda.setListaMateriales(new ArrayList<MaterialCapacitacion>(),false);
		this.panelBusqueda.construir();
	}

	public BusquedaMaterialPanel getPanelBusqueda() {
		return panelBusqueda;
	}

	public void setPanelBusqueda(BusquedaMaterialPanel panelVideo) {
		this.panelBusqueda= panelVideo;
	}


	public List<MaterialCapacitacion> buscar(String Criterio,String campoBusqueda) {
		List<MaterialCapacitacion> resultado=new ArrayList<MaterialCapacitacion>();
		HashSet<MaterialCapacitacion> sinRepetidos=new HashSet<MaterialCapacitacion>();
		switch(Criterio) {
		case ("TITULO"):
			sinRepetidos.add(materialDAO.dameBiblio().buscarTitulo(campoBusqueda));
			break;
		case("CALIFICACI�N"):
			sinRepetidos.addAll(materialDAO.dameBiblio().buscarCalificacion(Integer.valueOf(campoBusqueda).intValue()));
			break;
			
		case("TEMA"):
			sinRepetidos.addAll(materialDAO.dameBiblio().buscarTema(campoBusqueda));
			break;
		}
		resultado.addAll(sinRepetidos);
		return resultado;
	}
	
	public List<MaterialCapacitacion> buscar(String Criterio,String fechaInf,String fechaSup) throws ParseException {
		Date fecha1 = new SimpleDateFormat("dd/MM/yyyy").parse(fechaInf);
		Date fecha2 = new SimpleDateFormat("dd/MM/yyyy").parse(fechaSup);
		HashSet<MaterialCapacitacion> sinRepetidos=new HashSet<MaterialCapacitacion>();
		List<MaterialCapacitacion> resultado=new ArrayList<MaterialCapacitacion>();
		sinRepetidos.addAll(materialDAO.dameBiblio().rango(fecha1, fecha2));
		resultado.addAll(sinRepetidos);
		return resultado;

	}
	
	public List<MaterialCapacitacion> ordenarPor(String CriterioOrdenamiento,List<MaterialCapacitacion> lista){
		List<MaterialCapacitacion> resultado=new ArrayList<MaterialCapacitacion>();
		BibliotecaABB materialOrdenado=new BibliotecaABB();
		
		for(MaterialCapacitacion mat :lista) {
			materialOrdenado.agregar(mat);
		}
		switch(CriterioOrdenamiento) {
		case("TITULO"):
			resultado.addAll(materialOrdenado.getMateriales().inOrden());
			break;
		case("CALIFICACI�N"):
			materialOrdenado.ordenarPorCalificacion();
			resultado.addAll(materialOrdenado.getMateriales().inOrden());
			break;
		case("PRECIO"):
			materialOrdenado.ordenarPorPrecio(true);
			resultado.addAll(materialOrdenado.getMateriales().inOrden());
			break;
		case("FECHA"):
			materialOrdenado.ordenarPorFecha();
			resultado.addAll(materialOrdenado.getMateriales().inOrden());
			break;
		case("RELEVANCIA"):
			materialOrdenado.ordenarPorRelevancia();
			resultado.addAll(materialOrdenado.getMateriales().inOrden());
			break;
		
		}
		return resultado;

	}

}
