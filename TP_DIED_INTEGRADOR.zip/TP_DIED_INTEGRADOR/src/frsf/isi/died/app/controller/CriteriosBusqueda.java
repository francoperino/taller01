package frsf.isi.died.app.controller;

public enum CriteriosBusqueda {
	TITULO,CALIFICACION,FECHA,PRECIO,TEMA

}
