package frsf.isi.died.app.controller;

import java.awt.BorderLayout;
import java.text.ParseException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import frsf.isi.died.app.vista.grafo.ControlPanel;
import frsf.isi.died.app.vista.grafo.GrafoPanel;
import frsf.isi.died.app.vista.material.BusquedaArbolAgregar;
import frsf.isi.died.app.vista.material.BusquedaEnArbol;
import frsf.isi.died.app.vista.material.BusquedaMaterialPanel;
import frsf.isi.died.app.vista.material.LibroPanel;
import frsf.isi.died.app.vista.material.LibroPanelEditable;
import frsf.isi.died.app.vista.material.VideoPanel;
import frsf.isi.died.app.vista.material.VideoPanelEditable;
import frsf.isi.died.app.vista.material.Wishlist;


public class MenuController {

	private JFrame framePrincipal;
	
	public MenuController(JFrame f) {
		this.framePrincipal = f;
	}
	
	public void showView(TiposAcciones accion) {
		switch (accion) {
		case ABM_LIBROS:
			LibroPanel panelLibros = new LibroPanel();
			LibroController controller = new LibroController(panelLibros);
			controller.crearPanel();
			framePrincipal.setContentPane(controller.getPanelLibro());
			break;
		case EDIT_LIBROS:
			LibroPanelEditable panelLibros1 = new LibroPanelEditable();
			LibroEditableController controllerEditLibro = new LibroEditableController(panelLibros1);
			controllerEditLibro.crearPanel();
			framePrincipal.setContentPane(controllerEditLibro.getPanelLibro());
			break;
		case ABM_VIDEOS:
			VideoPanel panelVideos = new VideoPanel();
			VideoController controller1 = new VideoController(panelVideos);
			controller1.crearPanel();
			framePrincipal.setContentPane(controller1.getPanelVideo());
			break;
		case EDIT_VIDEOS:
			VideoPanelEditable panelVideosEditable = new VideoPanelEditable();
			VideoEditableController controller2 = new VideoEditableController(panelVideosEditable);
			controller2.crearPanel();
			framePrincipal.setContentPane(controller2.getPanelVideo());
			break;
		case VER_GRAFO:
			JPanel panel = new JPanel(new BorderLayout());
			ControlPanel controlPanel = new ControlPanel();
			GrafoPanel grafoPanel = new GrafoPanel();
			GrafoController grfController = new GrafoController(grafoPanel,controlPanel);
			panel.add(controlPanel , BorderLayout.PAGE_START);
			panel.add(grafoPanel , BorderLayout.CENTER);
			framePrincipal.setContentPane(panel);
			break;	
		case BUSQ:
			BusquedaMaterialPanel panelBusq = new BusquedaMaterialPanel();
			BuscarController controllerBusq=new BuscarController(panelBusq);
			controllerBusq.crearPanel();
			framePrincipal.setContentPane(controllerBusq.getPanelBusqueda());
			break;
		case WISHLIST:
			Wishlist listaDeseos=new Wishlist();
			listaDeseos.construir();
			framePrincipal.setContentPane(listaDeseos);
			break;
		case ARBOL:
			BusquedaArbolAgregar arbol=new BusquedaArbolAgregar();
			framePrincipal.setContentPane(arbol);
			break;
		case ARBOLBUSQ:
			BusquedaEnArbol arbolbusq=new BusquedaEnArbol();
			framePrincipal.setContentPane(arbolbusq);
		default:
			break;
		}
		
		framePrincipal.pack();
		framePrincipal.setSize(880, 600);

	}
	
	
}
