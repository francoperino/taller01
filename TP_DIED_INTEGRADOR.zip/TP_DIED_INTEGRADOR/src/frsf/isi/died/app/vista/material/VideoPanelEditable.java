package frsf.isi.died.app.vista.material;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import frsf.isi.died.app.controller.VideoController;
import frsf.isi.died.app.controller.VideoEditableController;
import frsf.isi.died.tp.modelo.productos.Relevancia;
import frsf.isi.died.tp.modelo.productos.Video;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class VideoPanelEditable extends JPanel{
	
	private JScrollPane scrollPane;
	private JTable tabla;
	private JLabel lblId;
	private JLabel lblTitulo;
	private JLabel lblCosto;
	private JLabel lblDuracion;
	private JLabel lblRelevancia;
	private JLabel lblFecha;
	private JLabel lblCalificacion;
	private JLabel lblTema;

	private JTextField txtId;
	private JTextField txtTitulo;
	private JTextField txtCosto;
	private JTextField txtDuracion;
	private JTextField txtFecha;
	private JTextField txtCalificacion;
	private JTextField txtTema;

	int id_buscado;
	private JComboBox boxRelevancia;

	private JButton btnActualizar;
	private JButton btnBorrar;
	
	private VideoTableModel tableModel;

	private VideoEditableController controller;
	
	public VideoPanelEditable() {
		this.setLayout(new GridBagLayout());
		tableModel = new VideoTableModel();
	}
	
	public void habilitarTexto(boolean b) {
		txtId.setEnabled(false);
    	txtTitulo.setEnabled(b);
    	txtCalificacion.setEnabled(b);
    	txtCosto.setEnabled(b);
    	txtDuracion.setEnabled(b);
    	txtFecha.setEnabled(b);
    	boxRelevancia.setEnabled(b);
    	txtTema.setEnabled(b);
	}
	
	public void construir() {
		GridBagConstraints gridConst= new GridBagConstraints();
				
		lblId= new JLabel("Id: ");
		gridConst.gridx=0;
		gridConst.gridy=0;
		this.add(lblId, gridConst);
		
		txtId = new JTextField();
		txtId.setColumns(5);
		gridConst.gridx=1;
		this.add(txtId, gridConst);
		
		lblTitulo = new JLabel("Titulo: ");
		gridConst.gridx=2;
		gridConst.gridy=0;
		this.add(lblTitulo, gridConst);
		
		txtTitulo = new JTextField();
		txtTitulo.setColumns(20);
		gridConst.gridx=3;
		gridConst.gridwidth=3;
		this.add(txtTitulo, gridConst);
		
		lblCalificacion = new JLabel("Calificaci�n: ");
		gridConst.anchor=gridConst.WEST;
		gridConst.gridx=6;
		this.add(lblCalificacion, gridConst);
		
		txtCalificacion = new JTextField();
		txtCalificacion.setColumns(3);
		gridConst.gridx=7;
		this.add(txtCalificacion, gridConst);
		
		lblTema = new JLabel("Tema: ");
		//gridConst.anchor=gridConst.WEST;
		gridConst.gridx=8;
		this.add(lblTema, gridConst);
		
		txtTema = new JTextField();
		txtTema.setColumns(10);
		gridConst.anchor=gridConst.CENTER;

		gridConst.gridx=9;
		this.add(txtTema, gridConst);
		

		btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener( e ->{
			try {
				Double costo = Double.valueOf(txtCosto.getText());
				Integer duracion = Integer.valueOf(txtDuracion.getText());
				int calificacion=Integer.valueOf(txtCalificacion.getText());
				controller.actualizarVideo(id_buscado,txtTitulo.getText(), costo, duracion,txtFecha.getText(),(Relevancia)boxRelevancia.getSelectedItem(),calificacion,txtTema.getText());
				txtTitulo.setText("");
				txtCosto.setText("");
				txtDuracion.setText("");
				txtId.setText("");
				txtCalificacion.setText("");
				txtFecha.setText("");
				txtTema.setText("");
				habilitarTexto(false);
				
			}catch(Exception ex) {
			    JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos incorrectos", JOptionPane.ERROR_MESSAGE);
			}
		});
		gridConst.gridwidth=1;
		//gridConst.weightx=1.0;
		gridConst.anchor = GridBagConstraints.EAST;
		gridConst.gridx=10;
		this.add(btnActualizar, gridConst);
		
		
		lblCosto= new JLabel("Costo: ");		
		gridConst.gridx=0;
		gridConst.gridy=1;
		gridConst.weightx=0.0;
		this.add(lblCosto, gridConst);
		
		txtCosto = new JTextField();
		txtCosto.setColumns(5);
		gridConst.gridx=1;
		this.add(txtCosto, gridConst);
		
		lblDuracion= new JLabel("Duraci�n: ");		
		gridConst.gridx=2;
		this.add(lblDuracion, gridConst);
		
		txtDuracion = new JTextField();
		txtDuracion.setColumns(5);
		gridConst.gridx=3;
		this.add(txtDuracion, gridConst);

		lblFecha= new JLabel("Fecha: ");		
		gridConst.gridx=4;
		this.add(lblFecha, gridConst);
		
		txtFecha = new JTextField();
		txtFecha.setColumns(6);
		gridConst.gridx=5;
		this.add(txtFecha, gridConst);
		
		lblRelevancia= new JLabel("Relevancia: ");		
		gridConst.gridx=6;
		this.add(lblRelevancia, gridConst);
		
		boxRelevancia=new JComboBox();
		boxRelevancia.setModel(new DefaultComboBoxModel(Relevancia.values()));
		gridConst.gridx=7;
		this.add(boxRelevancia, gridConst);
		
		btnBorrar= new JButton("Borrar");
		btnBorrar.setEnabled(false);
		btnBorrar.addActionListener(e->{
			
			controller.eliminarVideo(id_buscado);
			txtTitulo.setText("");
			txtCosto.setText("");
			txtDuracion.setText("");
			txtId.setText("");
			txtCalificacion.setText("");
			txtFecha.setText("");
			habilitarTexto(false);
			btnBorrar.setEnabled(false);
			});
		
		gridConst.gridx=10;
		gridConst.weightx=1.0;
		gridConst.anchor = GridBagConstraints.EAST;
		this.add(btnBorrar, gridConst);
		
		habilitarTexto(false);

		tabla = new JTable(this.tableModel);
		tabla.setFillsViewportHeight(true);
		scrollPane= new JScrollPane(tabla);

		gridConst.gridx=0;
		gridConst.gridwidth=11;	
		gridConst.gridy=2;
		gridConst.weighty=1.0;
		gridConst.weightx=1.0;
		gridConst.fill=GridBagConstraints.BOTH;
		gridConst.anchor=GridBagConstraints.PAGE_START;		
		this.add(scrollPane, gridConst);
		
		tabla.addMouseListener(new MouseAdapter() {

	        public void mouseClicked (MouseEvent me) {
	            if (me.getClickCount() == 2) {
	            	btnBorrar.setEnabled(true);
	            	int fila=tabla.getSelectedRow();
	            	habilitarTexto(true);
	        		txtId.setText(tabla.getValueAt(fila, 0).toString());
	        		txtTitulo.setText(tabla.getValueAt(fila, 1).toString());
	        		txtCosto.setText(tabla.getValueAt(fila,2 ).toString());
	        		txtDuracion.setText(tabla.getValueAt(fila, 3).toString());
	        		txtFecha.setText(tabla.getValueAt(fila, 4).toString());
	        		txtCalificacion.setText(tabla.getValueAt(fila, 7).toString());
	        		txtTema.setText(tabla.getValueAt(fila,8).toString());
					id_buscado=Integer.valueOf(txtId.getText());

	            }
	        }
	    });
	}

	public VideoEditableController getController() {
		return controller;
	}

	public void setController(VideoEditableController controller) {
		this.controller = controller;
	}
	
	public void setListaVideos(List<Video> videosLista,boolean actualizar) {
		this.tableModel.setVideos(videosLista);
		if(actualizar) this.tableModel.fireTableDataChanged();
	}
}
