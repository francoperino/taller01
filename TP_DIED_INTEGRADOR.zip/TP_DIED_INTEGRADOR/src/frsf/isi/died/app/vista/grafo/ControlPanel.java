/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frsf.isi.died.app.vista.grafo;


import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.JTableHeader;

import frsf.isi.died.app.controller.GrafoController;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;

/**
 *
 * @author mdominguez
 */
public class ControlPanel extends JPanel {
    
    private JComboBox<MaterialCapacitacion> cmbVertice1; 
    private JComboBox<MaterialCapacitacion> cmbVertice2; 
    private JComboBox listaTemas; 
    private JTextField txtLongitudCamino; 
    private JButton btnBuscarCamino; 
    private JButton btnAceptar; 
    private JLabel inicio;
    private JLabel destino;
    private JLabel cantidad;
    private JLabel lblLista;
    private JTable tablaRank;
    private JScrollPane scroll;

    public int cont;

    private GrafoController controller;
    private List<MaterialCapacitacion> listaVertices;
        
    public void removerObjetos() {
    	if(lblLista!=null) {
    		this.remove(lblLista);
    		lblLista=null;
    		this.remove(tablaRank);
    		this.remove(cmbVertice1);
    		this.remove(btnBuscarCamino);
    		this.remove(scroll);

    	}
    	else {
    		this.remove(inicio);
    		this.remove(destino);
    		this.remove(cantidad);
    		this.remove(cmbVertice1);
    		this.remove(cmbVertice2);
    		this.remove(txtLongitudCamino);
    		this.remove(btnBuscarCamino);
    	}
    }
    
    public void menuOpciones(List<MaterialCapacitacion> listaVertices) {
    	JComboBox cmbMenu=new JComboBox();
    	btnAceptar=new JButton("Aceptar");
    	cmbMenu.addItem("");
    	cmbMenu.addItem("Todos los caminos");
    	cmbMenu.addItem("Caminos entre");
    	cmbMenu.addItem("Page Rank");
    	this.add(cmbMenu);
    	this.add(btnAceptar);
    	btnAceptar.addActionListener(
    			e -> { 
    				if(cmbVertice1!=null)
    					this.removerObjetos();

    				switch(cmbMenu.getSelectedItem().toString()) {
    	    			case ("Caminos entre"):
    	    				cont=0;
    	    				armarPanel(listaVertices);
    	    				this.updateUI();
    	    				break;
    	    			case ("Todos los caminos"):
    	    				cont=0;
    	    				todosCaminos(listaVertices);
    	    				this.updateUI();
    	    				break;
    	    			case ("Page Rank"):
    	    				pageRank(listaVertices);
	    					this.updateUI();

    	    				break;
    	    			default:
    	    				break;
    	    		}

                }
        );
    	
    	
    }
    
    public void pageRank(List<MaterialCapacitacion> listaVertices) {
    	List<String> temas=new ArrayList<String>();
    	for(MaterialCapacitacion mat :listaVertices) {
    		if(!temas.contains(mat.getTema()))
    			temas.add(mat.getTema());
    	}
    	this.cmbVertice1=new JComboBox(temas.toArray());
    	this.btnBuscarCamino=new JButton("Ok");
    	this.btnBuscarCamino.addActionListener(
                e -> { 
                	if(scroll!=null)
                		this.remove(scroll);
                	List<MaterialCapacitacion> resultado=new ArrayList<MaterialCapacitacion>();
                    resultado.addAll(controller.pageRank(cmbVertice1.getSelectedItem().toString()));
                    this.crearTabla(resultado);
                    this.scroll=new JScrollPane(tablaRank);
                    this.tablaRank.setRowHeight(25);
                    this.add(scroll);
                    tablaRank.setEnabled(false);
    				this.updateUI();

                }
        );
        this.add(lblLista=new JLabel("Lista de temas: "));       
    	this.add(cmbVertice1);
    	this.add(btnBuscarCamino);
    	
    	}
    
    public void armarPanel( List<MaterialCapacitacion> listaVertices){
    	this.listaVertices = listaVertices;
    	this.cmbVertice1 = new JComboBox(listaVertices.toArray()); 
        this.cmbVertice2 = new JComboBox(listaVertices.toArray()); 
        this.txtLongitudCamino = new JTextField(5); 
        this.btnBuscarCamino = new JButton("Buscar Camino");
        this.btnBuscarCamino.addActionListener(
                e -> { 
                    Integer n =Integer.parseInt(txtLongitudCamino.getText());
                    int bandera;
                	Integer idOrigen = this.listaVertices.get(cmbVertice1.getSelectedIndex()).getId();
                    Integer idDestino= this.listaVertices.get(cmbVertice2.getSelectedIndex()).getId();
                    bandera=controller.buscarTodosCaminos(idOrigen,idDestino,cont,n); 
                    if(bandera==-1)
                    	cont=1;
                    else
                    	cont++;
                }
        );
        this.add(inicio=new JLabel("Vertice Origen"));        
    	this.add(cmbVertice1);
    	this.add(destino=new JLabel("Vertice Destino"));
    	this.add(cmbVertice2);
    	this.add(cantidad=new JLabel("Cantidad de saltos"));        
    	this.add(txtLongitudCamino);        
    	this.add(btnBuscarCamino);   
    }

    public void todosCaminos( List<MaterialCapacitacion> listaVertices){
    	this.listaVertices = listaVertices;
    	this.cmbVertice1 = new JComboBox(listaVertices.toArray()); 
        this.cmbVertice2 = new JComboBox(listaVertices.toArray()); 
        this.txtLongitudCamino = new JTextField(5); 
        this.btnBuscarCamino = new JButton("Buscar Caminos");
        this.btnBuscarCamino.addActionListener(
                e -> { 
                   // Integer n =Integer.parseInt(txtLongitudCamino.getText());
                    int bandera;
                	Integer idOrigen = this.listaVertices.get(cmbVertice1.getSelectedIndex()).getId();
                    Integer idDestino= this.listaVertices.get(cmbVertice2.getSelectedIndex()).getId();
                    bandera=controller.buscarTodosCaminos(idOrigen,idDestino,cont,100); 
                    if(bandera==-1)
                    	cont=1;
                    else
                    	cont++;
                }
        );
        cantidad=new JLabel();
        this.add(inicio=new JLabel("Vertice Origen"));        
    	this.add(cmbVertice1);
    	this.add(destino=new JLabel("Vertice Destino"));
    	this.add(cmbVertice2);
    	this.add(btnBuscarCamino);   
    }
    
    public GrafoController getController() {
        return controller;
    }

    public void setController(GrafoController controller) {
        this.controller = controller;
    }

    private void crearTabla(List<MaterialCapacitacion> datosTabla) {
    	Vector<String> columnas = new Vector();
    	columnas.addElement("Material");
    	columnas.addElement("Page Rank");
    	Vector<Vector<String>> dataVector = new Vector<Vector<String>>();
    	for(MaterialCapacitacion mate:datosTabla) {
    		Vector<String> aux=new Vector<String>();
    		aux.add(mate.getTitulo());
    		aux.add(String.valueOf(mate.getPagerankNew()));
    		dataVector.add(aux);
    	}

    	this.tablaRank=new JTable(dataVector,columnas);
    }
}
