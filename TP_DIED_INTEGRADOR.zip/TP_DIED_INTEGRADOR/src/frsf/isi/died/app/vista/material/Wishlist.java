package frsf.isi.died.app.vista.material;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import frsf.isi.died.app.dao.MaterialCapacitacionDao;
import frsf.isi.died.app.dao.MaterialCapacitacionDaoDefault;
import frsf.isi.died.tp.estructuras.Monticulo;
import frsf.isi.died.tp.modelo.productos.Libro;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;
import frsf.isi.died.tp.modelo.productos.Video;

public class Wishlist extends JPanel{

	private MaterialCapacitacionDao materialDAO;
	private BusquedaTableModel BusqTableW;
	private JTable tabla;
	

	private List<MaterialCapacitacion> cargarPorPrioridad() {
		Monticulo comparador=new Monticulo();
		PriorityQueue<MaterialCapacitacion> monticulo = new PriorityQueue<MaterialCapacitacion>(comparador);
		for(MaterialCapacitacion mat: materialDAO.getBiblioteca().materiales()) {
			monticulo.add(mat);
		}
		List<MaterialCapacitacion>ordenado=new ArrayList<MaterialCapacitacion>();
		while(!monticulo.isEmpty()) {
			ordenado.add(monticulo.poll());
		}
		return ordenado;
	}
	
	public Wishlist() {
		this.setLayout(new GridBagLayout());
		BusqTableW=new BusquedaTableModel();
		materialDAO = new MaterialCapacitacionDaoDefault("");
		BusqTableW.setMateriales(cargarPorPrioridad());


	}
	
	public void agregarWishlist(int id) {
		MaterialCapacitacion mat=materialDAO.findById(id);
		if(mat.esLibro())
			materialDAO.agregarLibroWishlist((Libro) mat);
		else
			materialDAO.agregarVideoWishlist((Video) mat);
	}
	
	public void construir() {
		GridBagConstraints gridConst= new GridBagConstraints();
		
		tabla = new JTable(this.BusqTableW);
		tabla.setFillsViewportHeight(true);
		JScrollPane scrollPane = new JScrollPane(tabla);
		tabla.setRowSelectionAllowed(true);
		gridConst.gridx=0;
		gridConst.gridwidth=5;	
		gridConst.gridy=0;
		gridConst.weighty=1.0;
		gridConst.weightx=1.0;
		gridConst.fill=GridBagConstraints.BOTH;
		gridConst.anchor=GridBagConstraints.LINE_START;		
		this.add(scrollPane, gridConst);
	}
	
	public void setListaMateriales(List<MaterialCapacitacion> materialesLista,boolean actualizar) {
		this.BusqTableW.setMateriales(materialesLista);
		
	}
	
	
}
