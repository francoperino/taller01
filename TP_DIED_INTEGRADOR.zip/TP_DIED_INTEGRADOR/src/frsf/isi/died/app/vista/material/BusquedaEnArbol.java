package frsf.isi.died.app.vista.material;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import frsf.isi.died.app.dao.MaterialCapacitacionDaoDefault;
import frsf.isi.died.tp.estructuras.TipoNodo;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;

public class BusquedaEnArbol extends JPanel{

	private JLabel lblCriterio1;
	private JLabel lblCriterio2=new JLabel("Criterio 2");
	private JComboBox cmbCriterio1=new JComboBox(TipoNodo.values());
	private JComboBox cmbCriterio2=new JComboBox(TipoNodo.values());
	private JTextField txtCriterio1=new JTextField();
	private JTextField txtCriterio2=new JTextField();
	private JButton btnBuscar=new JButton("Buscar");
	private BusquedaTableModel BusqTable;
	private JScrollPane scrollPane;
	private JTable tabla;
	private MaterialCapacitacionDaoDefault material=new MaterialCapacitacionDaoDefault();



	public BusquedaEnArbol() {
		this.setLayout(new GridBagLayout());
		BusqTable=new BusquedaTableModel();
		BusqTable.setMateriales(new ArrayList<MaterialCapacitacion>());
		this.construir();
	}
	
	private void construir() {
		GridBagConstraints gridConst= new GridBagConstraints();
	
		lblCriterio1=new JLabel("Criterio 1");
		gridConst.gridx=0;
		gridConst.gridy=0;
		this.add(lblCriterio1,gridConst);
		
		gridConst.gridx=1;
		this.add(cmbCriterio1,gridConst);
		
		gridConst.gridx=2;
		txtCriterio1.setColumns(15);
		this.add(txtCriterio1,gridConst);
		
		gridConst.gridx=3;
		this.add(lblCriterio2,gridConst);
		
		gridConst.gridx=4;
		this.add(cmbCriterio2,gridConst);
		
		gridConst.gridx=5;
		txtCriterio2.setColumns(15);
		this.add(txtCriterio2,gridConst);
		
		gridConst.gridx=6;
		this.add(btnBuscar, gridConst);
		
		btnBuscar.addActionListener( e ->{
			String criterio1=this.cmbCriterio1.getSelectedItem().toString();
			String valor1=this.txtCriterio1.getText();
			String criterio2=this.cmbCriterio2.getSelectedItem().toString();
			String valor2=this.txtCriterio2.getText();
			BusqTable.setMateriales(buscar(criterio1, valor1, criterio2, valor2));
			this.updateUI();
		});
		
		tabla = new JTable(this.BusqTable);
		tabla.setFillsViewportHeight(true);
		scrollPane= new JScrollPane(tabla);
		gridConst.gridx=0;
		gridConst.gridwidth=7;	
		gridConst.gridy=1;
		gridConst.weighty=1.0;
		gridConst.weightx=1.0;
		gridConst.fill=GridBagConstraints.BOTH;
		gridConst.anchor=GridBagConstraints.LINE_START;		
		this.add(scrollPane, gridConst);

		
		}
	
	private List<MaterialCapacitacion> buscar(String criterio1,String valor1,String criterio2,String valor2){
		List<MaterialCapacitacion> listaDeMateriales=this.material.listaMateriales();
		List<MaterialCapacitacion> resultado=new ArrayList<MaterialCapacitacion>();

		for(MaterialCapacitacion mat:listaDeMateriales) {
			if(!valor2.isEmpty()) {
				if(mat.buscarArbol(valor1, criterio1)&&mat.buscarArbol(valor2, criterio2)) {
					resultado.add(mat);
				}
			}
			else {
				if(mat.buscarArbol(valor1, criterio1)) {
					resultado.add(mat);
				}
			}
				
		}
		return resultado;
	}
}
