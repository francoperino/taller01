package frsf.isi.died.app.vista.material;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import frsf.isi.died.app.controller.LibroController;
import frsf.isi.died.app.controller.LibroEditableController;
import frsf.isi.died.app.controller.VideoEditableController;
import frsf.isi.died.tp.modelo.productos.Libro;
import frsf.isi.died.tp.modelo.productos.Relevancia;

public class LibroPanelEditable extends JPanel {
	private JScrollPane scrollPane;
	private JTable tabla;
	private JLabel lblId;
	private JLabel lblTitulo;
	private JLabel lblCosto;
	private JLabel lblPrecioCompra;
	private JLabel lblPaginas;
	private JLabel lblRelevancia;
	private JLabel lblFecha;
	private JLabel lblCalificacion;
	private JLabel lblTema;
	private int id_actualizar;
	
	private JTextField txtId;
	private JTextField txtTitulo;
	private JTextField txtCosto;
	private JTextField txtPrecioCompra;
	private JTextField txtPaginas;
	private JTextField txtFecha;
	private JTextField txtCalificacion;
	private JTextField txtTema;

	public void habilitarTexto(Boolean b) {
		txtId.setEnabled(false);
		txtTitulo.setEnabled(b);
		txtCosto.setEnabled(b);
		txtPrecioCompra.setEnabled(b);
		txtPaginas.setEnabled(b);
		txtFecha.setEnabled(b);
		txtCalificacion.setEnabled(b);
		txtTema.setEnabled(b);
		boxRelevancia.setEnabled(b);
	}
	
	private JComboBox boxRelevancia;

	private JButton btnActualizar;
	private JButton btnBorrar;
	
	private LibroTableModel tableModel;

	private LibroEditableController controller;
	
	public LibroPanelEditable() {
		this.setLayout(new GridBagLayout());
		tableModel = new LibroTableModel();
	
		
	}
	
	public void construir() {
		GridBagConstraints gridConst= new GridBagConstraints();

		lblId= new JLabel("Id: ");
		gridConst.gridx=0;
		gridConst.gridy=0;
		this.add(lblId, gridConst);
		
		txtId = new JTextField();
		txtId.setColumns(5);
		gridConst.gridx=1;
		//gridConst.gridwidth=1;
		this.add(txtId, gridConst);
		
		lblTitulo = new JLabel("Titulo: ");
		gridConst.gridx=2;
		this.add(lblTitulo, gridConst);
		
		txtTitulo = new JTextField();
		txtTitulo.setColumns(30);
		gridConst.gridx=3;
		gridConst.gridwidth=5;
		this.add(txtTitulo, gridConst);
		
		lblCalificacion = new JLabel("Calificaci�n: ");
		gridConst.anchor=gridConst.WEST;
		gridConst.gridx=8;
		this.add(lblCalificacion, gridConst);
		
		txtCalificacion = new JTextField();
		txtCalificacion.setColumns(5);
		gridConst.gridx=9;
		this.add(txtCalificacion, gridConst);

		lblTema = new JLabel("Tema: ");
		gridConst.anchor=gridConst.WEST;
		gridConst.gridx=10;
		this.add(lblTema, gridConst);
		
		txtTema = new JTextField();
		txtTema.setColumns(5);
		gridConst.gridx=11;
		this.add(txtTema, gridConst);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener( e ->{
			try {
				Double costo = Double.valueOf(txtCosto.getText());
				Double precio = Double.valueOf(txtPrecioCompra.getText());
				Integer paginas = Integer.valueOf(txtPaginas.getText());
				int calificacion=Integer.valueOf(txtCalificacion.getText());
				controller.actualizarLibro(id_actualizar,txtTitulo.getText(), costo, precio, paginas,txtFecha.getText(),(Relevancia)boxRelevancia.getSelectedItem(),calificacion,txtTema.getText());
				txtTitulo.setText("");
				txtCosto.setText("");
				txtId.setText("");
				txtCalificacion.setText("");
				txtFecha.setText("");
				txtPaginas.setText("");
				txtPrecioCompra.setText("");
				txtTema.setText("");
				habilitarTexto(false);
				
			}catch(Exception ex) {
			    JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos incorrectos", JOptionPane.ERROR_MESSAGE);
			}
		});
		gridConst.gridwidth=1;
		gridConst.weightx=1.0;
		gridConst.anchor = GridBagConstraints.LINE_START;
		gridConst.gridx=12;
		this.add(btnActualizar, gridConst);
		
		
		lblCosto= new JLabel("Costo: ");		
		gridConst.gridx=0;
		gridConst.gridy=1;
		gridConst.weightx=0.0;
		this.add(lblCosto, gridConst);
		
		txtCosto = new JTextField();
		txtCosto.setColumns(5);
		gridConst.gridx=1;
		this.add(txtCosto, gridConst);
		
		lblPrecioCompra= new JLabel("Precio Compra: ");
		gridConst.gridx=2;
		this.add(lblPrecioCompra, gridConst);
		
		txtPrecioCompra = new JTextField();
		txtPrecioCompra.setColumns(5);
		gridConst.gridx=3;
		this.add(txtPrecioCompra, gridConst);
		
		lblPaginas= new JLabel("Paginas: ");		
		gridConst.gridx=4;
		this.add(lblPaginas, gridConst);
		
		txtPaginas = new JTextField();
		txtPaginas.setColumns(5);
		gridConst.gridx=5;
		this.add(txtPaginas, gridConst);

		lblFecha= new JLabel("Fecha: ");		
		gridConst.gridx=6;
		this.add(lblFecha, gridConst);
		
		txtFecha = new JTextField();
		txtFecha.setColumns(10);
		gridConst.gridx=7;
		this.add(txtFecha, gridConst);
		
		lblRelevancia= new JLabel("Relevancia: ");		
		gridConst.gridx=8;
		this.add(lblRelevancia, gridConst);
		
		boxRelevancia=new JComboBox();
		boxRelevancia.setModel(new DefaultComboBoxModel(Relevancia.values()));
		gridConst.gridx=9;
		this.add(boxRelevancia, gridConst);

		btnBorrar= new JButton("Borrar");
		btnBorrar.setEnabled(false);
		btnBorrar.addActionListener(e->{
			
			controller.eliminarLibro(id_actualizar);
			txtTitulo.setText("");
			txtCosto.setText("");
			txtId.setText("");
			txtCalificacion.setText("");
			txtFecha.setText("");
			txtPaginas.setText("");
			txtPrecioCompra.setText("");
			habilitarTexto(false);
			});
		gridConst.gridx=11;
		gridConst.weightx=1.0;
		gridConst.anchor = GridBagConstraints.LINE_START;
		this.add(btnBorrar, gridConst);
		
		habilitarTexto(false);
		
		tabla = new JTable(this.tableModel);
		tabla.setFillsViewportHeight(true);
		scrollPane= new JScrollPane(tabla);
		
		gridConst.gridx=0;
		gridConst.gridwidth=11;	
		gridConst.gridy=2;
		gridConst.weighty=1.0;
		gridConst.weightx=1.0;
		gridConst.fill=GridBagConstraints.BOTH;
		gridConst.anchor=GridBagConstraints.PAGE_START;		
		this.add(scrollPane, gridConst);
		
		tabla.addMouseListener(new MouseAdapter() {

	        public void mouseClicked (MouseEvent me) {
	            if (me.getClickCount() == 2) {
	            	btnBorrar.setEnabled(true);
	            	int fila=tabla.getSelectedRow();
	            	habilitarTexto(true);
	        		txtId.setText(tabla.getValueAt(fila, 0).toString());
	        		txtTitulo.setText(tabla.getValueAt(fila, 1).toString());
	        		txtPrecioCompra.setText(tabla.getValueAt(fila,2 ).toString());
	        		txtCosto.setText(tabla.getValueAt(fila,3).toString());
	        		txtPaginas.setText(tabla.getValueAt(fila,4).toString());
	        		txtFecha.setText(tabla.getValueAt(fila, 5).toString());
	        		txtCalificacion.setText(tabla.getValueAt(fila, 8).toString());
	        		txtTema.setText(tabla.getValueAt(fila, 9).toString());

	        		id_actualizar=Integer.valueOf((tabla.getValueAt(fila, 0).toString()));
	            }
	        }
	    });
	}
	
	public LibroEditableController getController() {
		return controller;
	}

	public void setController(LibroEditableController controller) {
		this.controller = controller;
	}
	
	public void setListaLibros(List<Libro> librosLista,boolean actualizar) {
		this.tableModel.setLibros(librosLista);
		if(actualizar) this.tableModel.fireTableDataChanged();
	}

}
