package frsf.isi.died.app.vista.material;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import frsf.isi.died.app.controller.VideoController;
import frsf.isi.died.tp.modelo.productos.Relevancia;
import frsf.isi.died.tp.modelo.productos.Video;

public class VideoPanel extends JPanel{
	private JScrollPane scrollPane;
	private JTable tabla;
	private JLabel lblId;
	private JLabel lblTitulo;
	private JLabel lblCosto;
	private JLabel lblDuracion;
	private JLabel lblRelevancia;
	private JLabel lblFecha;
	private JLabel lblCalificacion;
	private JLabel lblTema;

	private JTextField txtId;
	private JTextField txtTitulo;
	private JTextField txtCosto;
	private JTextField txtDuracion;
	private JTextField txtFecha;
	private JTextField txtCalificacion;
	private JTextField txtTema;


	private JComboBox boxRelevancia;
	
	private JButton btnAgregar;
	private JButton btnCancelar;
	
	private VideoTableModel tableModel;

	private VideoController controller;
	
	public VideoPanel() {
		this.setLayout(new GridBagLayout());
		tableModel = new VideoTableModel();
	}

	public void construir() {
		GridBagConstraints gridConst= new GridBagConstraints();
		lblId= new JLabel("Id: ");
		gridConst.gridx=0;
		gridConst.gridy=0;
		this.add(lblId, gridConst);
		
		txtId = new JTextField();
		txtId.setColumns(5);
		gridConst.gridx=1;
		//gridConst.gridwidth=1;
		this.add(txtId, gridConst);
		
		lblTitulo = new JLabel("Titulo: ");
		gridConst.gridx=2;
		gridConst.gridy=0;
		this.add(lblTitulo, gridConst);
		
		txtTitulo = new JTextField();
		txtTitulo.setColumns(20);
		gridConst.gridx=3;
		gridConst.gridwidth=3;
		this.add(txtTitulo, gridConst);
		
		lblCalificacion = new JLabel("Calificaci�n: ");
		gridConst.anchor=gridConst.WEST;
		gridConst.gridx=6;
		this.add(lblCalificacion, gridConst);
		
		txtCalificacion = new JTextField();
		txtCalificacion.setColumns(3);
		gridConst.gridx=7;
		this.add(txtCalificacion, gridConst);
		
		lblTema = new JLabel("Tema: ");
		//gridConst.anchor=gridConst.WEST;
		gridConst.gridx=8;
		this.add(lblTema, gridConst);
		
		txtTema = new JTextField();
		//gridConst.anchor=gridConst.WEST;

		txtTema.setColumns(5);
		gridConst.gridx=9;
		this.add(txtTema, gridConst);
		

		btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener( e ->{
			try {
				int id=Integer.valueOf(txtId.getText());
				Double costo = Double.valueOf(txtCosto.getText());
				Integer duracion = Integer.valueOf(txtDuracion.getText());
				int calificacion=Integer.valueOf(txtCalificacion.getText());
				controller.agregarVideo(id,txtTitulo.getText(), costo, duracion,txtFecha.getText(),(Relevancia)boxRelevancia.getSelectedItem(),calificacion,txtTema.getText());
				txtTitulo.setText("");
				txtCosto.setText("");
				txtDuracion.setText("");
				txtId.setText("");
				txtCalificacion.setText("");
				txtFecha.setText("");
			}catch(Exception ex) {
			    JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos incorrectos", JOptionPane.ERROR_MESSAGE);
			}
		});
		gridConst.gridwidth=1;
		gridConst.weightx=1.0;
		gridConst.anchor = GridBagConstraints.EAST;
		gridConst.gridx=10;
		this.add(btnAgregar, gridConst);
		
		
		lblCosto= new JLabel("Costo: ");		
		gridConst.gridx=0;
		gridConst.gridy=1;
		gridConst.weightx=0.0;
		this.add(lblCosto, gridConst);
		
		txtCosto = new JTextField();
		txtCosto.setColumns(5);
		gridConst.gridx=1;
		this.add(txtCosto, gridConst);
		
		lblDuracion= new JLabel("Duraci�n: ");		
		gridConst.gridx=2;
		this.add(lblDuracion, gridConst);
		
		txtDuracion = new JTextField();
		txtDuracion.setColumns(5);
		gridConst.gridx=3;
		this.add(txtDuracion, gridConst);

		lblFecha= new JLabel("Fecha: ");		
		gridConst.gridx=4;
		this.add(lblFecha, gridConst);
		
		txtFecha = new JTextField();
		txtFecha.setColumns(6);
		gridConst.gridx=5;
		this.add(txtFecha, gridConst);
		
		lblRelevancia= new JLabel("Relevancia: ");		
		gridConst.gridx=6;
		this.add(lblRelevancia, gridConst);
		
		boxRelevancia=new JComboBox();
		boxRelevancia.setModel(new DefaultComboBoxModel(Relevancia.values()));
		gridConst.gridx=7;
		this.add(boxRelevancia, gridConst);
		
		btnCancelar= new JButton("Cancelar");
		btnCancelar.addActionListener(e->{
			this.setVisible(false);
			});
		gridConst.gridx=8;
		gridConst.weightx=1.0;
		gridConst.anchor = GridBagConstraints.LINE_START;
		this.add(btnCancelar, gridConst);
		
		tabla = new JTable(this.tableModel);
		tabla.setFillsViewportHeight(true);
		scrollPane= new JScrollPane(tabla);
		tabla.setRowSelectionAllowed(false);
		
		gridConst.gridx=0;
		gridConst.gridwidth=10;	
		gridConst.gridy=2;
		gridConst.weighty=1.0;
		gridConst.weightx=1.0;
		gridConst.fill=GridBagConstraints.BOTH;
		gridConst.anchor=GridBagConstraints.PAGE_START;		
		this.add(scrollPane, gridConst);
	}

	public VideoController getController() {
		return controller;
	}

	public void setController(VideoController controller) {
		this.controller = controller;
	}
	
	public void setListaVideos(List<Video> videosLista,boolean actualizar) {
		this.tableModel.setVideos(videosLista);
		if(actualizar) this.tableModel.fireTableDataChanged();
	}
	
}
