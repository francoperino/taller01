package frsf.isi.died.app.vista.material;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import frsf.isi.died.app.controller.LibroController;
import frsf.isi.died.tp.modelo.productos.Libro;
import frsf.isi.died.tp.modelo.productos.Relevancia;

public class LibroPanel extends JPanel{
	
	private JScrollPane scrollPane;
	private JTable tabla;
	private JLabel lblId;
	private JLabel lblTitulo;
	private JLabel lblCosto;
	private JLabel lblPrecioCompra;
	private JLabel lblPaginas;
	private JLabel lblRelevancia;
	private JLabel lblFecha;
	private JLabel lblCalificacion;
	private JLabel lblTema;
	
	private JTextField txtId;
	private JTextField txtTitulo;
	private JTextField txtCosto;
	private JTextField txtPrecioCompra;
	private JTextField txtPaginas;
	private JTextField txtFecha;
	private JTextField txtCalificacion;
	private JTextField txtTema;

	
	private JButton btnAgregar;
	private JButton btnCancelar;
	
	private JComboBox boxRelevancia;

	private LibroTableModel tableModel;

	private LibroController controller;
	
	public LibroPanel() {
		this.setLayout(new GridBagLayout());
		tableModel = new LibroTableModel();
	}
	
	public void construir() {
		GridBagConstraints gridConst= new GridBagConstraints();
		
		lblId= new JLabel("Id: ");
		gridConst.gridx=0;
		gridConst.gridy=0;
		this.add(lblId, gridConst);
		
		txtId = new JTextField();
		txtId.setColumns(5);
		gridConst.gridx=1;
		//gridConst.gridwidth=1;
		this.add(txtId, gridConst);
		
		lblTitulo = new JLabel("Titulo: ");
		gridConst.gridx=2;
		this.add(lblTitulo, gridConst);
		
		txtTitulo = new JTextField();
		txtTitulo.setColumns(30);
		gridConst.gridx=3;
		gridConst.gridwidth=5;
		this.add(txtTitulo, gridConst);
		
		lblCalificacion = new JLabel("Calificaci�n: ");
		gridConst.anchor=gridConst.WEST;
		gridConst.gridx=8;
		this.add(lblCalificacion, gridConst);
		
		txtCalificacion = new JTextField();
		txtCalificacion.setColumns(5);
		gridConst.gridx=9;
		this.add(txtCalificacion, gridConst);
		
		lblTema = new JLabel("Tema: ");
		gridConst.anchor=gridConst.WEST;
		gridConst.gridx=10;
		this.add(lblTema, gridConst);
		
		txtTema = new JTextField();
		gridConst.anchor=gridConst.CENTER;

		txtTema.setColumns(5);
		gridConst.gridx=11;
		this.add(txtTema, gridConst);


		btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener( e ->{
			try {
				Double costo = Double.valueOf(txtCosto.getText());
				int id=Integer.valueOf(txtId.getText());
				Double precio = Double.valueOf(txtPrecioCompra.getText());
				Integer paginas = Integer.valueOf(txtPaginas.getText());
				int calificacion=Integer.valueOf(txtCalificacion.getText());
				controller.agregarLibro(id,txtTitulo.getText(), costo, precio, paginas,txtFecha.getText(),(Relevancia)boxRelevancia.getSelectedItem(),calificacion,txtTema.getText());
				txtTitulo.setText("");
				txtCosto.setText("");
				txtId.setText("");
				txtCalificacion.setText("");
				txtFecha.setText("");
				txtPaginas.setText("");
				txtPrecioCompra.setText("");
				
			}catch(Exception ex) {
			    JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos incorrectos", JOptionPane.ERROR_MESSAGE);
			}
		});
		gridConst.gridwidth=1;
		gridConst.weightx=1.0;
		gridConst.anchor = GridBagConstraints.EAST;
		gridConst.gridx=12;
		this.add(btnAgregar, gridConst);
		
		
		lblCosto= new JLabel("Costo: ");		
		gridConst.gridx=0;
		gridConst.gridy=1;
		gridConst.weightx=0.0;
		this.add(lblCosto, gridConst);
		
		txtCosto = new JTextField();
		txtCosto.setColumns(5);
		gridConst.gridx=1;
		this.add(txtCosto, gridConst);
		
		lblPrecioCompra= new JLabel("Precio Compra: ");
		gridConst.gridx=2;
		this.add(lblPrecioCompra, gridConst);
		
		txtPrecioCompra = new JTextField();
		txtPrecioCompra.setColumns(5);
		gridConst.gridx=3;
		this.add(txtPrecioCompra, gridConst);
		
		lblPaginas= new JLabel("Paginas: ");		
		gridConst.gridx=4;
		this.add(lblPaginas, gridConst);
		
		txtPaginas = new JTextField();
		txtPaginas.setColumns(5);
		gridConst.gridx=5;
		this.add(txtPaginas, gridConst);

		lblFecha= new JLabel("Fecha: ");		
		gridConst.gridx=6;
		this.add(lblFecha, gridConst);
		
		txtFecha = new JTextField();
		txtFecha.setColumns(10);
		gridConst.gridx=7;
		this.add(txtFecha, gridConst);
		
		lblRelevancia= new JLabel("Relevancia: ");		
		gridConst.gridx=8;
		this.add(lblRelevancia, gridConst);
		
		boxRelevancia=new JComboBox();
		boxRelevancia.setModel(new DefaultComboBoxModel(Relevancia.values()));
		gridConst.gridx=9;
		this.add(boxRelevancia, gridConst);

		btnCancelar= new JButton("Cancelar");
		btnCancelar.addActionListener(e->{
			this.setVisible(false);
			});
		gridConst.gridx=11;
		gridConst.weightx=1.0;
		gridConst.anchor = GridBagConstraints.EAST;
		this.add(btnCancelar, gridConst);
		
		tabla = new JTable(this.tableModel);
		tabla.setFillsViewportHeight(true);
		scrollPane= new JScrollPane(tabla);
		
		gridConst.gridx=0;
		gridConst.gridwidth=12;	
		gridConst.gridy=2;
		gridConst.weighty=1.0;
		gridConst.weightx=1.0;
		gridConst.fill=GridBagConstraints.BOTH;
		gridConst.anchor=GridBagConstraints.PAGE_START;		
		this.add(scrollPane, gridConst);
	}

	public LibroController getController() {
		return controller;
	}

	public void setController(LibroController controller) {
		this.controller = controller;
	}
	
	public void setListaLibros(List<Libro> librosLista,boolean actualizar) {
		this.tableModel.setLibros(librosLista);
		if(actualizar) this.tableModel.fireTableDataChanged();
	}

}