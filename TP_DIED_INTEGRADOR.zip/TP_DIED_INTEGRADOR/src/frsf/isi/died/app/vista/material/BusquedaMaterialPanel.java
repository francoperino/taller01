package frsf.isi.died.app.vista.material;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import frsf.isi.died.app.controller.BuscarController;
import frsf.isi.died.app.controller.CriteriosBusqueda;
import frsf.isi.died.app.controller.VideoController;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;
import frsf.isi.died.tp.modelo.productos.Video;

public class BusquedaMaterialPanel extends JPanel {

	private Wishlist wish=new Wishlist();
	private int filaSeleccionada;
	private BusquedaTableModel BusqTable;
	private BuscarController controller;
	
	public BusquedaMaterialPanel() {
		this.setLayout(new GridBagLayout());
		BusqTable=new BusquedaTableModel();
	}
	
	private JScrollPane scrollPane;
	private JTable tabla;
	private JLabel lblBusqueda;
	private JLabel lblOrdenar;
	private JTextField txtBusqueda1;
	private JTextField txtBusqueda2;

	private JComboBox boxBusqueda;
	private JComboBox boxOrdenar;

	private JButton btnBuscar;
	private JButton btnCancelar;
	private JButton btnWishlist;

	
	public void construir() {
		GridBagConstraints gridConst= new GridBagConstraints();
				
		txtBusqueda1 = new JTextField();
		txtBusqueda1.setColumns(10);
		gridConst.gridx=0;
		gridConst.gridy=0;
		this.add(txtBusqueda1, gridConst);
		
		txtBusqueda2 = new JTextField();
		txtBusqueda2.setColumns(6);
		txtBusqueda2.setVisible(false);
		gridConst.gridx=1;
		this.add(txtBusqueda2, gridConst);
		
		lblBusqueda= new JLabel("Buscar por: ");
		gridConst.weightx=0.0;
		gridConst.gridx=2;
		this.add(lblBusqueda, gridConst);
		
		boxBusqueda=new JComboBox();
		boxBusqueda.addItem("TITULO");
		boxBusqueda.addItem("CALIFICACI�N");
		boxBusqueda.addItem("FECHA");
		boxBusqueda.addItem("TEMA");

		gridConst.gridx=3;

		this.add(boxBusqueda, gridConst);
		
		lblOrdenar= new JLabel("Ordenar por: ");
		gridConst.gridx=4;
		this.add(lblOrdenar, gridConst);
		
		boxOrdenar=new JComboBox();
		boxOrdenar.addItem("TITULO");
		boxOrdenar.addItem("CALIFICACI�N");
		boxOrdenar.addItem("FECHA");
		boxOrdenar.addItem("PRECIO");
		boxOrdenar.addItem("RELEVANCIA");
		gridConst.gridx=5;
		gridConst.anchor=GridBagConstraints.WEST;
		this.add(boxOrdenar, gridConst);
		
		boxBusqueda.addActionListener(e->{
			if(boxBusqueda.getSelectedItem().equals("FECHA")) {
				txtBusqueda1.setColumns(6);
				txtBusqueda2.setVisible(true);
				this.revalidate();
				}
			else {
				txtBusqueda1.setColumns(10);
				txtBusqueda2.setVisible(false);
				this.revalidate();
				}
		});
		
		btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener( e ->{
			try {
				
				List<MaterialCapacitacion> aux=new ArrayList<MaterialCapacitacion>();
				
				String campoBusqueda1=txtBusqueda1.getText();
				
				if(!boxBusqueda.getSelectedItem().equals("FECHA")) {
				
					
					aux.addAll(controller.buscar(boxBusqueda.getSelectedItem().toString(), campoBusqueda1));
				
				}else {
				
					String campoBusqueda2=txtBusqueda2.getText();
					
					aux.addAll(controller.buscar(boxBusqueda.getSelectedItem().toString(), campoBusqueda1,campoBusqueda2));
					
				}
				if(aux.get(0).equals(null)) {
					
					throw new Exception();
				}
				
				this.setListaMateriales((controller.ordenarPor(boxOrdenar.getSelectedItem().toString(), aux)),true);
				
			}catch(Exception ex) {
		    JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos incorrectos", JOptionPane.ERROR_MESSAGE);
		}});
		gridConst.gridwidth=1;
		gridConst.weightx=0.0;
		gridConst.gridx=6;
		this.add(btnBuscar, gridConst);
		
		btnWishlist = new JButton("Agregar a Wishlist");
		btnWishlist.addActionListener( e ->{
			int id_wish=Integer.valueOf(tabla.getValueAt(filaSeleccionada, 0).toString());
			String calificacion=tabla.getValueAt(filaSeleccionada, 5).toString();
			wish.agregarWishlist(id_wish);
		});
		
		gridConst.gridx=7;
		btnWishlist.setEnabled(false);
		this.add(btnWishlist,gridConst);
		
		tabla = new JTable(this.BusqTable);
		tabla.setFillsViewportHeight(true);
		scrollPane= new JScrollPane(tabla);
		tabla.setRowSelectionAllowed(true);
		gridConst.gridx=0;
		gridConst.gridwidth=7;	
		gridConst.gridy=1;
		gridConst.weighty=1.0;
		gridConst.weightx=1.0;
		gridConst.fill=GridBagConstraints.BOTH;
		gridConst.anchor=GridBagConstraints.LINE_START;		
		this.add(scrollPane, gridConst);
		
		tabla.addMouseListener(new MouseAdapter() {

	        public void mouseClicked (MouseEvent me) {
	            if (me.getClickCount() == 1) {
	            	filaSeleccionada=tabla.getSelectedRow();
	            	btnWishlist.setEnabled(true);
	        		
	            }
	        }
	    });
		
		
	}

	public BuscarController getController() {
		return controller;
	}

	public void setController(BuscarController controller) {
		this.controller = controller;
	}
	
	public void setListaMateriales(List<MaterialCapacitacion> materialesLista,boolean actualizar) {
		this.BusqTable.setMateriales(materialesLista);
		if(actualizar) this.BusqTable.fireTableDataChanged();
	}


}
