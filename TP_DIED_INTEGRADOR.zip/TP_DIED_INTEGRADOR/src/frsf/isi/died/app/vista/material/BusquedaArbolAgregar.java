package frsf.isi.died.app.vista.material;

import java.awt.GridBagLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import frsf.isi.died.app.dao.MaterialCapacitacionDaoDefault;
import frsf.isi.died.tp.estructuras.ArbolEneario;
import frsf.isi.died.tp.estructuras.TipoNodo;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;
import frsf.isi.died.tp.modelo.productos.Relevancia;

public class BusquedaArbolAgregar extends JPanel{

	private ArrayList<ArbolEneario> padres=new ArrayList<ArbolEneario>();

	private int indiceMaterial=0;
	private int indiceArbol=0;
	private ArbolEneario miArbol;
	private JComboBox listaMateriales;
	private JComboBox box1;
	private JComboBox box3;
	private JButton agregar=new JButton("Agregar");
	private JLabel lblTitulo=new JLabel("Titulo ");
	private JLabel lblNodo=new JLabel("Nodo padre ");
	private JLabel lblNodoHijo=new JLabel("Nodo hijo ");

	private JLabel lblValor=new JLabel("Valor ");

	private JTextField txtCampo=new JTextField();
	private MaterialCapacitacionDaoDefault materialDao=new MaterialCapacitacionDaoDefault();
	private String[] nivel1= {"METADATO","CAPITULO","RESUMEN"};
	private String[] nodos= {"AUTOR","EDITORIAL","FECHA","PALABRA_CLAVE","PARRAFO","CAPITULO","SECCION","PARRAFO_CAP","SITIO_WEB","SITIO_WEB_EJERCICIO","PALABRA_CLAVE_CAP"};
	private JComboBox listaTipoNodo=new JComboBox(TipoNodo.values());

	public BusquedaArbolAgregar() {
		this.setLayout(new GridBagLayout());
		this.construir();
	}
	
	private void construir() {
		
		this.listaMateriales=new JComboBox(materialDao.listaMateriales().toArray());
		listaMateriales.addActionListener( e ->{
			this.padres.clear();
			this.remove(box1);
			indiceMaterial=this.listaMateriales.getSelectedIndex();
			this.indiceArbol=0;
			miArbol=this.materialDao.listaMateriales().get(indiceMaterial).devolverArbol();
			padres.addAll(miArbol.devolverLista());
			this.box1=new JComboBox(padres.toArray());
			box1.addActionListener( g ->{
				indiceArbol=this.box1.getSelectedIndex();
			});
			this.add(box1);
			this.add(lblNodoHijo);
			this.add(listaTipoNodo);
			txtCampo.setColumns(15);
			this.add(txtCampo);
			
			this.add(agregar);
			this.updateUI();

		});
		//this.box2=new JComboBox(TipoNodo.values());
		this.agregar.addActionListener( f ->{
			this.agregarHijo(txtCampo.getText(), listaTipoNodo.getSelectedItem().toString(), indiceArbol,padres);
			this.indiceArbol=0;
			this.txtCampo.setText("");
			updateUI();
		});
		this.add(listaMateriales);
		this.add(lblNodo);			
		this.box1=new JComboBox();
		this.add(box1);
	}
	
	private void agregarHijo(String valor,String nodo,int ubicacion,ArrayList<ArbolEneario> padres) {
		ArbolEneario padre=padres.get(ubicacion);
		padre.agregarHijo(valor, TipoNodo.valueOf(nodo));
	}
	/*	box1.addActionListener( e ->{
			
			x=this.listaMateriales.getSelectedIndex();
			miArbol=this.materialDao.listaMateriales().get(x).devolverArbol();
			
			if(this.box2!=null) {
				this.remove(box2);
				this.remove(lblValor);
				this.remove(txtCampo);
				this.remove(agregar);
			}
			if(this.box3!=null)
				this.remove(box3);
			
			switch(box1.getSelectedItem().toString()) {
				case("METADATO"):
					this.box2=new JComboBox(metadatos);
					this.agregarNivel2();
					this.updateUI();
					break;
				case("CAPITULO"):
					this.box2=new JComboBox(capitulos);
					this.add(box2);
					this.updateUI();
					this.usarBox3(box2.getSelectedItem().toString());
					//this.agregarNivel2();
					
					break;
				case("RESUMEN"):
					this.box2=new JComboBox(resumen);
					this.agregarNivel2();
					this.updateUI();
					break;
					}
			
			
			
			});
		
		this.add(lblTitulo);
		this.add(listaMateriales);
		this.add(box1);
		this.agregar.addActionListener( e ->{
			try {
				
				this.miArbol.agregarHijo(txtCampo.getText(), TipoNodo.valueOf(box2.getSelectedItem().toString()));
				
			}catch(Exception ex) {
			    JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos incorrectos", JOptionPane.ERROR_MESSAGE);
			}
		});


	}
	private void botonNivel1() {
		
	}
	
	private void usarBox3(String seleccionado) {
		box2.addActionListener( e ->{
			if(this.box3!=null) {
				this.remove(box3);
				this.remove(lblValor);
				this.remove(txtCampo);
				this.remove(agregar);
			}
			switch(box2.getSelectedItem().toString()) {
			case("SECCION"):
				this.box3=new JComboBox(parrafoCap);
				this.add(box3);
				this.txtCampo=new JTextField();
				txtCampo.setColumns(10);
				this.add(lblValor);
				this.add(txtCampo);
				this.add(agregar);
				this.updateUI();
				break;
			case("METADATO_CAPITULO"):
				this.box3=new JComboBox(metadatosCap);
				this.agregarNivel3();
				this.updateUI();

				break;
			}
		});
		
	}
	private void agregarNivel2() {
		this.txtCampo=new JTextField();
		txtCampo.setColumns(10);
		this.add(box2);
		this.add(lblValor);
		this.add(txtCampo);
		this.add(agregar);
	}
	
	private void agregarNivel3() {
		this.txtCampo=new JTextField();
		txtCampo.setColumns(10);
		this.add(box3);
		this.add(lblValor);
		this.add(txtCampo);
		this.add(agregar);
	}*/
	
}
