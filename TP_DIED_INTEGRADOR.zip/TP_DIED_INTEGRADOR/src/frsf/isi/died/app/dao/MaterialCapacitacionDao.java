package frsf.isi.died.app.dao;

import java.util.List;

import frsf.isi.died.app.dao.util.CsvDatasource;
import frsf.isi.died.tp.modelo.Biblioteca;
import frsf.isi.died.tp.modelo.productos.Libro;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;
import frsf.isi.died.tp.modelo.productos.Video;

public interface MaterialCapacitacionDao {

	public void agregarLibro(Libro mat);
	public void agregarVideo(Video mat);
	public List<Libro> listaLibros();
	public List<Video> listaVideos();
	public List<MaterialCapacitacion> listaMateriales();
	public MaterialCapacitacion findById(Integer id);
	public void crearCamino(Integer idOrigen, Integer idDestino);
	public List<List<MaterialCapacitacion>> buscarCamino(Integer idOrigen, Integer idDestino, Integer saltos);
	public Biblioteca dameBiblio();
	public Biblioteca getBiblioteca();
	public CsvDatasource getDataResource();
	void recargarGrafo();
	void agregarVideoWishlist(Video mat);
	void agregarLibroWishlist(Libro mat);
	public List<MaterialCapacitacion> calcularPageRank(String tema);
}
