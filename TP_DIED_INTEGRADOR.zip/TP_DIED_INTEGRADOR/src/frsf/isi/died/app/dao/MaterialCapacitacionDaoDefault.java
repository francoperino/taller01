package frsf.isi.died.app.dao;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import frsf.isi.died.app.dao.util.CsvDatasource;
import frsf.isi.died.tp.estructuras.Grafo;
import frsf.isi.died.tp.estructuras.Vertice;
import frsf.isi.died.tp.modelo.Biblioteca;
import frsf.isi.died.tp.modelo.BibliotecaABB;
import frsf.isi.died.tp.modelo.productos.Libro;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;
import frsf.isi.died.tp.modelo.productos.Video;

public class MaterialCapacitacionDaoDefault implements MaterialCapacitacionDao{

	private static Grafo<MaterialCapacitacion> GRAFO_MATERIAL  = new Grafo<MaterialCapacitacion>();
	
	private static Biblioteca biblioteca = new BibliotecaABB();
		
	private CsvDatasource dataSource;
	
	public Biblioteca dameBiblio() {
		for(int i=0;i<this.listaMateriales().size();i++) {
			biblioteca.agregar(this.listaMateriales().get(i));
			}
		return biblioteca;
	}
	
	public Biblioteca getBiblioteca() {
		return biblioteca;
	}

	public MaterialCapacitacionDaoDefault() {
		dataSource = new CsvDatasource();

		if(GRAFO_MATERIAL.esVacio()) {
			
			cargarGrafo();
		}
	}
	
	public MaterialCapacitacionDaoDefault(String x) {
		biblioteca=new BibliotecaABB(); 
		dataSource = new CsvDatasource();
		cargarWish();
	}
	
	@Override
	public void recargarGrafo() {
		GRAFO_MATERIAL= new Grafo();
		cargarGrafo();
	}

	private void cargarWish() {
		List<List<String>> libros = dataSource.readFile("librosW.csv");
		for(List<String> filaLibro : libros) {
			Libro aux = new Libro();
			aux.loadFromStringRow(filaLibro);
			biblioteca.agregar(aux);
		}
		List<List<String>> videos= dataSource.readFile("videosW.csv");
		for(List<String> filaVideo: videos) {
			Video aux = new Video();
			aux.loadFromStringRow(filaVideo);
			biblioteca.agregar(aux);
		}
	 }
	
	private void cargarGrafo() {
		List<List<String>> libros = dataSource.readFile("libros.csv");
		for(List<String> filaLibro : libros) {
			Libro aux = new Libro();
			aux.loadFromStringRow(filaLibro);
			GRAFO_MATERIAL.addNodo(aux);
		}
		List<List<String>> videos= dataSource.readFile("videos.csv");
		for(List<String> filaVideo: videos) {
			Video aux = new Video();
			aux.loadFromStringRow(filaVideo);
			GRAFO_MATERIAL.addNodo(aux);
		}
		List<List<String>> aristas= dataSource.readFile("aristas.csv");
		for(List<String> filaArista: aristas) {
			MaterialCapacitacion n1 = this.findById(Integer.valueOf(filaArista.get(0)));
			MaterialCapacitacion n2 = this.findById(Integer.valueOf(filaArista.get(2)));
			GRAFO_MATERIAL.conectar(n1, n2);
		}
 	}
	@Override
	public void agregarLibro(Libro mat) {
		GRAFO_MATERIAL.addNodo(mat);	
		biblioteca.agregar(mat);
		try {
			dataSource.agregarFilaAlFinal("libros.csv", mat);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void agregarVideo(Video mat) {
		//mat.setId(++SECUENCIA_ID_Video);
		GRAFO_MATERIAL.addNodo(mat);				
		biblioteca.agregar(mat);
		try {
			dataSource.agregarFilaAlFinal("videos.csv", mat);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void agregarLibroWishlist(Libro mat) {
		GRAFO_MATERIAL.addNodo(mat);	
		biblioteca.agregar(mat);
		try {
			dataSource.agregarFilaAlFinal("librosW.csv", mat);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void agregarVideoWishlist(Video mat) {
		//mat.setId(++SECUENCIA_ID_Video);
		GRAFO_MATERIAL.addNodo(mat);				
		biblioteca.agregar(mat);
		try {
			dataSource.agregarFilaAlFinal("videosW.csv", mat);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Libro> listaLibros() {
		List<Libro> libros = new ArrayList<>();
		for(MaterialCapacitacion mat : GRAFO_MATERIAL.listaVertices()) {
			if(mat.esLibro()) libros.add((Libro)mat); 
		}
		return libros;
	}

	@Override
	public List<Video> listaVideos() {
		List<Video> vids = new ArrayList<>();
		for(MaterialCapacitacion mat : GRAFO_MATERIAL.listaVertices()) {
			if(mat.esVideo()) vids.add((Video)mat); 
		}
		return vids;
	}

	@Override
	public List<MaterialCapacitacion> listaMateriales() {
		// TODO Auto-generated method stub
		return GRAFO_MATERIAL.listaVertices();
	}

	@Override
	public MaterialCapacitacion findById(Integer id) {
		// TODO Auto-generated method stub
		for(MaterialCapacitacion mat : GRAFO_MATERIAL.listaVertices()) {
			if(mat.getId().equals(id)) return mat;
		}
		return null;
	}

	@Override
	public List buscarCamino(Integer idOrigen, Integer idDestino, Integer saltos) {
		MaterialCapacitacion n1 = this.findById(idOrigen);
		MaterialCapacitacion n2 = this.findById(idDestino);
		return GRAFO_MATERIAL.buscarCaminoNSaltos(n1, n2, saltos);
	}
	
	@Override
	public void crearCamino(Integer idOrigen, Integer idDestino) {
		MaterialCapacitacion n1 = this.findById(idOrigen);
		MaterialCapacitacion n2 = this.findById(idDestino);
		GRAFO_MATERIAL.conectar(n1, n2);
		List<String> fila = new ArrayList<>();
		fila.add(n1.getId()+"");
		fila.add(n1.getTitulo());
		fila.add(n2.getId()+"");
		fila.add(n2.getTitulo());
		try {
			dataSource.agregarFilaAlFinal("aristas.csv", fila);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public CsvDatasource getDataResource() {
		return dataSource;
	}
	
	 public List<MaterialCapacitacion> calcularPageRank(String tema){
		 List<MaterialCapacitacion> listaMateriales=new ArrayList<MaterialCapacitacion>();
		 for(MaterialCapacitacion aux :this.listaMateriales()) 
		    	if(aux.getTema().equals(tema))
		    		listaMateriales.add(aux);
		 while(this.calcularDiferencia(listaMateriales)) {
			 for(MaterialCapacitacion mat: listaMateriales) {
				 mat.setPagerankOld(mat.getPagerankNew());
				 mat.setPagerankNew(this.GRAFO_MATERIAL.calcularPageRank(mat));
				 this.GRAFO_MATERIAL.actualizarPageRankNew(mat, mat.getPagerankNew());
				 this.GRAFO_MATERIAL.actualizarPageRankOld(mat, mat.getPagerankOld());
				 }
			}
		 
		 return listaMateriales;
		 }

	private boolean calcularDiferencia(List<MaterialCapacitacion> lista) {
		double e=0.00000001;
		for(MaterialCapacitacion mate : lista) {
			double nuevo=mate.getPagerankNew();
			double viejo=mate.getPagerankOld();
			double diferencia=nuevo-viejo;
			if(diferencia>=e) {
				return true;
			}
		}
		return false;
	}
	
	
}
