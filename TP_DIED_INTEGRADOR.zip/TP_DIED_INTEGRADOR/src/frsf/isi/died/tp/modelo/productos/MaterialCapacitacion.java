/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frsf.isi.died.tp.modelo.productos;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import frsf.isi.died.app.dao.util.CsvRecord;
import frsf.isi.died.tp.estructuras.ArbolEneario;
import frsf.isi.died.tp.estructuras.TipoNodo;
import frsf.isi.died.tp.util.Ordenable;

/**
 * Representa de manera abstracta los materiales de capacitación
 * 
 * @author mdominguez
 */
public abstract class MaterialCapacitacion implements Ordenable,Comparable<MaterialCapacitacion>, CsvRecord{
	

	private ArbolEneario arbol;
	
	public ArbolEneario devolverArbol() {
		return arbol;
	}
	
	protected double pagerankOld;
	
	public double getPagerankOld() {
		return pagerankOld;
	}

	public void setPagerankOld(double pagerankOld) {
		this.pagerankOld = pagerankOld;
	}

	protected double pagerankNew=1;
	
	public double getPagerankNew() {
		return pagerankNew;
	}

	public void setPagerankNew(double pagerankNew) {
		this.pagerankNew = pagerankNew;
	}

	protected Integer id;
	/**
	 * Titulo del material
	 */
	protected String titulo;

	/**
	 * Costo básico que debe sumarse al precio por el mero hecho de publicarlo en el
	 * portal
	 */
	protected Double costo;
	
	protected Date fechaPublicacion;
	
	public Date getFechaPublicacion() {
		return fechaPublicacion;
	}

	public void setFechaPublicacion(Date fechaPublic) {
		this.fechaPublicacion = fechaPublic;
	}
	
	protected String fechaPublic;
	
	public String getFechaPublic() {
		return fechaPublic;
	}

	public void setFechaPublic(String fechaPublic) {
		this.fechaPublic = fechaPublic;
	}
	
	protected int calificacion;
	
	protected Relevancia relevancia;
	
	protected String tema;

	public String getTema() {
		return tema;
	}

	public void setTema(String tema) {
		this.tema = tema;
	}

	/**
	 * Constructor por defecto
	 */
	public MaterialCapacitacion() {
		this(0,"en desarrollo",0.0);
	}

	/**
	 * Constructor que recibe como argumento un ID y un Titulo
	 * 
	 * @param id
	 * @param titulo
	 */
	public MaterialCapacitacion(Integer id, String titulo) {
		this(id,titulo,0.0);
	}

	/**
	 * Constructor que recibe como argumento un ID y un costo
	 * 
	 * @param id
	 * @param titulo
	 */
	
	public MaterialCapacitacion(Integer id,String titulo, Double costo) {
		
		this.id =id;
		this.titulo = titulo;
		this.costo = costo;
		this.arbol=new ArbolEneario(titulo);

	}
	
	public MaterialCapacitacion(Integer id,String titulo, Double costo,String fecha,Relevancia relevancia,int calificacion,String tema) {
		this.arbol=new ArbolEneario(titulo);
		this.id =id;
		this.titulo = titulo;
		this.costo = costo;
		this.fechaPublic=fecha;
		this.relevancia=relevancia;
		this.calificacion=calificacion;
		this.tema=tema;
		//String startDateString = "06/27/2007";
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date startDate;
		try {
			this.fechaPublicacion = (Date)df.parse(fecha);
		} catch (java.text.ParseException e) {
				e.printStackTrace();
			}
		
	}

	public int getCalificacion() {
		return this.calificacion;
	}
	
	public Relevancia getRelevancia() {
		return this.relevancia;
	}
	
	
	public String getTitulo() {
		return titulo;
	}

	public Double getCosto() {
		return costo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setCosto(Double costo) {
		this.costo = costo;
	}
	

	/**
	 * El precio de un material se define según el tipo del material y toma como
	 * base el costo del mismo
	 * 
	 * @return
	 */
	public abstract Double precio();
	
	/**
	 * Retorna verdadero si es una instancia de libro, falso en caso contrario
	 * @return
	 */
	public abstract Boolean esLibro();

	/**
	 * Retorna verdadero si es una instancia de video, falso en caso contrario
	 * @return
	 */
	public abstract Boolean esVideo();
	

	/**
	 * Retorna un valor numerico que será utilizado para ordenar los elementos
	 * @return
	 */
	@Override
	public final int valor() {
		return this.precio().intValue();
	}

	/**
	 * el método toString imprime el titulo, y el precio de un libro
	 * usando el formato : [Titulo: <titulo> ; Precio: <precio> ]
	 */
	@Override
	public String toString() {
		return "[Titulo " +this.titulo+"; PRECIO: "+this.precio()+"]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((titulo == null) ? 0 : titulo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MaterialCapacitacion other = (MaterialCapacitacion) obj;
		if (titulo == null) {
			if (other.titulo != null)
				return false;
		} else if (!titulo.equals(other.titulo))
			return false;
		return true;
	}

	@Override
	public int compareTo(MaterialCapacitacion o) {
		int aux = this.titulo.compareTo(o.titulo);
		if(aux==0) {
			aux = this.precio().compareTo(o.precio());
		}
		return aux;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	

	public void setLibro(String titulo, Double costo, Double precioCompra, Integer paginas, String fecha,
			Relevancia rel, int calificacion,String tema) {
		// TODO Auto-generated method stub
		
	}

	public void setVideo(String tit, Double cos, Integer dur, String fec, Relevancia rel, int cal,String tema) {
		// TODO Auto-generated method stub
		
	}
	
	public boolean buscarArbol(String valor,String tiponodo) {
		return this.arbol.buscarArbol(valor, TipoNodo.valueOf(tiponodo));
	}
	
}
