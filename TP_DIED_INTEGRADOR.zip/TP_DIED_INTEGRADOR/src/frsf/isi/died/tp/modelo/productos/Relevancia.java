package frsf.isi.died.tp.modelo.productos;

public enum Relevancia {
	BAJA,MEDIA,ALTA
}
