/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frsf.isi.died.tp.modelo.productos;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author mdominguez
 */
public class Video extends MaterialCapacitacion {

    private Integer duracionEnSegundos;
    private static final Double _VALOR_SEGUNDO = 0.15;

    public Video() {
        super();
    }

    public Video(Integer id,String titulo){
        super(id,titulo);
        this.duracionEnSegundos=0;
    }
    
    public Video(Integer id,String titulo, Double costo) {
        super(id,titulo, costo);
        this.duracionEnSegundos = 0;
    }

    public Video(Integer id,String titulo, Double costo, Integer duracion) {
        super(id,titulo, costo);
        this.duracionEnSegundos = duracion;
    }

    public Video(Integer id,String titulo, Double costo, Integer duracion,String fecha,Relevancia rel,int calificacion,String tema) {
        super(id,titulo, costo,fecha,rel,calificacion,tema);
        this.duracionEnSegundos = duracion;
    }
    
    @Override
    public Double precio() {
        return costo + (duracionEnSegundos * _VALOR_SEGUNDO);
    }

    public Integer getDuracionEnSegundos() {
        return duracionEnSegundos;
    }

    public void setDuracionEnSegundos(Integer duracionEnSegundos) {
        this.duracionEnSegundos = duracionEnSegundos;
    }

	@Override
	public Boolean esLibro() {
		return false;
	}

	@Override
	public Boolean esVideo() {
		return true;
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof Video && super.equals(obj) ;
	}
	
	@Override
	public List<String> asCsvRow() {
		List<String> lista = new ArrayList<String>();
		lista.add(this.id+"");
		lista.add("\""+ this.titulo.toString() + "\"");
		lista.add(this.costo.toString());
		lista.add(this.duracionEnSegundos.toString());
		lista.add(this.fechaPublic.toString());
		lista.add(this.relevancia.toString());
		lista.add(Integer.toString(this.calificacion));
		lista.add(this.tema.toString());
		return lista;
	}
	

	@Override
	public void loadFromStringRow(List<String> datos) {
		this.devolverArbol().setearTitulo(titulo);
		this.id =Integer.valueOf(datos.get(0));
		this.titulo = datos.get(1).replaceAll("\"", "");
		this.devolverArbol().setearTitulo(titulo);
		this.costo =Double.valueOf(datos.get(2));
		this.duracionEnSegundos =Integer.valueOf(datos.get(3));
		this.fechaPublic=datos.get(4);
		this.relevancia=relevancia.valueOf(datos.get(5));
		this.calificacion=Integer.valueOf(datos.get(6));
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date startDate;
		try {
			this.fechaPublicacion = (Date)df.parse(datos.get(4));
		} catch (java.text.ParseException e) {
				e.printStackTrace();
			}
		this.tema=datos.get(7);
	}

	@Override
	public void setVideo(String tit,Double cos,Integer dur,String fec,Relevancia rel,int cal,String tema) {
		this.titulo=tit;
		this.costo=cos;
		this.duracionEnSegundos=dur;
		this.fechaPublic=fec;
		this.relevancia=rel;
		this.calificacion=cal;
		this.tema=tema;
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date startDate;
		try {
			this.fechaPublicacion = (Date)df.parse(fec);
		} catch (java.text.ParseException e) {
				e.printStackTrace();
			}
	}
	
	@Override
	public String toString() {
		return "[Video: " +this.titulo+"; PRECIO: "+this.precio()+"]";
	}
}