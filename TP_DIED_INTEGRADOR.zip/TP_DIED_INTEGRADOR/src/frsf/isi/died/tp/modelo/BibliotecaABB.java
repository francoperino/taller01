package frsf.isi.died.tp.modelo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import frsf.isi.died.tp.estructuras.Arbol;
import frsf.isi.died.tp.estructuras.ArbolBinarioBusqueda;
import frsf.isi.died.tp.estructuras.ArbolVacio;
import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;

public class BibliotecaABB implements Biblioteca {

	private Arbol materiales;
	private Boolean flagOrdenarPorPrecio;
	private Comparator<MaterialCapacitacion> comparaTitulo= (mc1,mc2)-> mc1.getTitulo().compareTo(mc2.getTitulo());
	private Comparator<MaterialCapacitacion> comparaPrecio= (mc1,mc2)-> mc1.precio().intValue()- mc2.precio().intValue();
	private Comparator<MaterialCapacitacion> comparaCalificacion= (mc1,mc2)-> mc1.getCalificacion()- mc2.getCalificacion();
	private Comparator<MaterialCapacitacion> comparaFecha= (mc1,mc2)-> mc1.getFechaPublicacion().compareTo(mc2.getFechaPublicacion()) ;
	private Comparator<MaterialCapacitacion> comparaRelevancia= (mc1,mc2)-> mc1.getRelevancia().compareTo(mc2.getRelevancia()) ;
	private Comparator<MaterialCapacitacion> comparaTema= (mc1,mc2)-> mc1.getTema().compareTo(mc2.getTema()) ;

	public BibliotecaABB() {
		this.materiales = new ArbolVacio();
		flagOrdenarPorPrecio= false;
	}
	
	public Arbol getMateriales() {
		return this.materiales;
	}
	
	@Override
	public void agregar(MaterialCapacitacion material) {
		if(this.materiales.esVacio()) this.materiales = new ArbolBinarioBusqueda(material, comparaTitulo);
		else{
			if(materiales.tamanio()<100)this.materiales.add(material);
		}
	}

	@Override
	public Integer cantidadMateriales() {
		// TODO Auto-generated method stub
		return materiales.tamanio();
	}

	@Override
	public Integer cantidadLibros() {
		// TODO Auto-generated method stub
		return materiales.tamanioLibros();
	}

	@Override
	public Integer cantidadVideos() {
		// TODO Auto-generated method stub
		return materiales.tamanioVideos();
	}

	@Override
	public List<MaterialCapacitacion> materiales() {
		// TODO RETORNAR LA LISTA DEL ARBOL ORDENADA ASCENDENTEMENTE		
		return this.materiales.inOrden();		
	}

	@Override
	public void imprimir() {
		// TODO IMPRIMIR LA LISTA DEL ARBOL ORDENADA ASCENDENTEMENTE
		materiales.imprimir();
	}

	@Override
	public void ordenarPorPrecio(Boolean b) {
		if((flagOrdenarPorPrecio && b) || (!flagOrdenarPorPrecio && !b ) ) {
			// no hago nada porque ya estaba ordenando por precio
			// y me pide que ordene por precio por lo tanto retorno
			return;
		}

		if(flagOrdenarPorPrecio && !b) {
			this.flagOrdenarPorPrecio = false;
			this.ordenarPorTitulo();
		}
		if(!flagOrdenarPorPrecio && b) {
			this.flagOrdenarPorPrecio= true;
			this.ordenarPorPrecio();
		}		
	}

	@Override
	public MaterialCapacitacion buscar(Integer precio) {
		// TODO Auto-generated method stub
		//if(!flagOrdenarPorPrecio) this.ordenarPorPrecio(true);
		this.ordenarPorPrecio();
		return this.materiales.buscar(precio);		
	}
	
	public List<MaterialCapacitacion> buscarCalificacion(int calificacion) {
		List<MaterialCapacitacion> resultado=new ArrayList<MaterialCapacitacion>();
		// TODO Auto-generated method stub
		//if(!flagOrdenarPorPrecio) this.ordenarPorPrecio(true);
		//this.ordenarPorCalificacion();
		resultado.addAll(this.materiales.buscarC(calificacion));
		return resultado;
	}
	
	public MaterialCapacitacion buscarTitulo(String titulo) {
		// TODO Auto-generated method stub
		//if(!flagOrdenarPorPrecio) this.ordenarPorPrecio(false);
		this.ordenarPorTitulo();
		return this.materiales.buscar(titulo);		
	}
	
	public Collection<MaterialCapacitacion> rango(Double costoMinimo,Double costoMax){
		if(!flagOrdenarPorPrecio) this.ordenarPorPrecio(true); 				
		return this.materiales.rango(costoMinimo, costoMax);
	}
	
	public List<MaterialCapacitacion> rango(Date fechaMinimo,Date fechaMaximo){
		this.ordenarPorFecha();		
		return this.materiales.rango(fechaMinimo, fechaMaximo);
	}
	
	private void ordenarPorPrecio() {
		// Creo un nuevo arbol que ordena comparando por PRECIO.
		// Obtengo la lista del �rbol acutal.
		// Paso cada elemento de la lista al nuevo �rbol.
		// ahora el nuevo �rbol cuando lo recorra ordenado, mostrar� los 
		// datos ordenados por PRECIO la pr�xima vez que se invoque en 
		// BibliotecaABB el m�todo imprimir() o materiales()
		ArbolBinarioBusqueda abb = new ArbolBinarioBusqueda(this.comparaPrecio);
		this.materiales.inOrden().stream().forEach(mat -> abb.add(mat));
		this.materiales = abb;
	}
	
	public void ordenarPorFecha() {
		// Creo un nuevo arbol que ordena comparando por PRECIO.
		// Obtengo la lista del �rbol acutal.
		// Paso cada elemento de la lista al nuevo �rbol.
		// ahora el nuevo �rbol cuando lo recorra ordenado, mostrar� los 
		// datos ordenados por PRECIO la pr�xima vez que se invoque en 
		// BibliotecaABB el m�todo imprimir() o materiales()
		ArbolBinarioBusqueda abb = new ArbolBinarioBusqueda(this.comparaFecha);
		this.materiales.inOrden().stream().forEach(mat -> abb.add(mat));
		this.materiales = abb;
	}
	
	public void ordenarPorRelevancia() {
		// Creo un nuevo arbol que ordena comparando por PRECIO.
		// Obtengo la lista del �rbol acutal.
		// Paso cada elemento de la lista al nuevo �rbol.
		// ahora el nuevo �rbol cuando lo recorra ordenado, mostrar� los 
		// datos ordenados por PRECIO la pr�xima vez que se invoque en 
		// BibliotecaABB el m�todo imprimir() o materiales()
		ArbolBinarioBusqueda abb = new ArbolBinarioBusqueda(this.comparaRelevancia);
		this.materiales.inOrden().stream().forEach(mat -> abb.add(mat));
		this.materiales = abb;
	}
	
	public void ordenarPorCalificacion() {
		// Creo un nuevo arbol que ordena comparando por PRECIO.
		// Obtengo la lista del �rbol acutal.
		// Paso cada elemento de la lista al nuevo �rbol.
		// ahora el nuevo �rbol cuando lo recorra ordenado, mostrar� los 
		// datos ordenados por PRECIO la pr�xima vez que se invoque en 
		// BibliotecaABB el m�todo imprimir() o materiales()
		ArbolBinarioBusqueda abb = new ArbolBinarioBusqueda(this.comparaCalificacion);
		this.materiales.inOrden().stream().forEach(mat -> abb.add(mat));
		this.materiales = abb;
	}
	
	private void ordenarPorTitulo() {
		// Creo un nuevo arbol que ordena comparando por titulo.
		// Obtengo la lista del �rbol acutal.
		// Paso cada elemento de la lista al nuevo �rbol.
		// ahora el nuevo �rbol cuando lo recorra ordenado, mostrar� los 
		// datos ordenados por titulo la pr�xima vez que se invoque en 
		// BibliotecaABB el m�todo imprimir() o materiales()
		ArbolBinarioBusqueda abb = new ArbolBinarioBusqueda(this.comparaTitulo);
		this.materiales.inOrden().stream().forEach(mat -> abb.add(mat));
		this.materiales = abb;
	}
	
	@Override
	public List<Integer> dameIDs(){
		List<Integer>IDs=new ArrayList<Integer>();
		for(int i=0;i<this.materiales().size();i++) {
			IDs.add(this.materiales().get(i).getId());
		}
		return IDs;
	}

	@Override
	public List<MaterialCapacitacion> buscarTema(String tema) {
		List<MaterialCapacitacion> resultado=new ArrayList<MaterialCapacitacion>();
		// TODO Auto-generated method stub
		//if(!flagOrdenarPorPrecio) this.ordenarPorPrecio(true);
		//this.ordenarPorCalificacion();
		resultado.addAll(this.materiales.buscarC(tema));
		return resultado;
		
	}

}
