package frsf.isi.died.tp.estructuras;

public enum TipoNodo {
	TITULO,
	AUTOR,
	EDITORIAL,
	FECHA,
	PALABRA_CLAVE,
	PARRAFO,
	METADATO,
	METADATO_CAPITULO,
	
	SECCION,
	
	CAPITULO,
	RESUMEN
	,SITIO_WEB,SITIO_WEB_EJERCICIO
}
