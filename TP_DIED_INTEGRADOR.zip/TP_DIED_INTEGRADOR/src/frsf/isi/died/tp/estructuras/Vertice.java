/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frsf.isi.died.tp.estructuras;

/**
 *
 * @author mdominguez
 */
public class Vertice<T> {

        private T valor;
	
        protected double pagerankOld=1;
        
        protected double pagerankNew=1;

    	
    	
	public double getPagerankOld() {
			return pagerankOld;
		}

		public void setPagerankOld(double pagerankOld) {
			this.pagerankOld = pagerankOld;
		}

		public double getPagerankNew() {
			return pagerankNew;
		}

		public void setPagerankNew(double pagerankNew) {
			this.pagerankNew = pagerankNew;
		}

	public Vertice(){	}
	 
	public Vertice(T v){
		this.valor = v;
	}
	
	public void setValor(T v){
		this.valor = v;
	}
	
	public T getValor(){
		return this.valor;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((valor == null) ? 0 : valor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vertice other = (Vertice) obj;
		if (valor == null) {
			if (other.valor != null)
				return false;
		} else if (!valor.equals(other.valor))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return valor.toString();
	}
	
	
}

