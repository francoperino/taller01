package frsf.isi.died.tp.estructuras;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import frsf.isi.died.tp.modelo.productos.MaterialCapacitacion;

public class Monticulo implements Comparator<MaterialCapacitacion>{
	private Comparator<MaterialCapacitacion> comparaPrecio= (mc1,mc2)-> mc2.precio().intValue()- mc1.precio().intValue();
	private Comparator<MaterialCapacitacion> comparaCalificacion= (mc1,mc2)-> mc2.getCalificacion()- mc1.getCalificacion();
	private Comparator<MaterialCapacitacion> comparaRelevancia= (mc1,mc2)-> mc2.getRelevancia().compareTo(mc1.getRelevancia()) ;

    private List<Comparator<MaterialCapacitacion>> comparadores=new ArrayList<Comparator<MaterialCapacitacion>>();
    
    public Monticulo() {
    	comparadores.add(comparaRelevancia);
    	comparadores.add(comparaCalificacion);
    	comparadores.add(comparaPrecio);

    }
    
	@Override
	public int compare(MaterialCapacitacion o1, MaterialCapacitacion o2) {
		for(Comparator<MaterialCapacitacion> comparator : comparadores) {
            if(comparator.compare(o1, o2)!=0) {
                return comparator.compare(o1, o2);
            }
		
	}
		return 0;
}
	
}
