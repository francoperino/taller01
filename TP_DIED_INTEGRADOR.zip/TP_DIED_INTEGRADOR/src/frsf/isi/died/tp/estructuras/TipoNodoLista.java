package frsf.isi.died.tp.estructuras;

public enum TipoNodoLista {
	AUTOR,
	EDITORIAL,
	FECHA,
	PALABRA_CLAVE,
	PARRAFO,
	METADATO_CAPITULO,
	
	SECCION,
	
	PARRAFO_CAP,
	CAPITULO,
	RESUMEN
	,PALABRA_CLAVE_CAP,SITIO_WEB,SITIO_WEB_EJERCICIO
}
