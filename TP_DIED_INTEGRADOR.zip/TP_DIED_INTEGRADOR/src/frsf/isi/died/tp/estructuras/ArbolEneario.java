package frsf.isi.died.tp.estructuras;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class ArbolEneario {

	private String valor;
	private TipoNodo tiponodo;
	private List<ArbolEneario> hijos;
	
	public void agregarHijo(String valor,TipoNodo tiponodo) {
		if(this.verificarCompatibilidad(this.tiponodo, tiponodo)) {
			ArbolEneario son=new ArbolEneario(valor,tiponodo);
			if(this.hijos==null)
				this.hijos=new ArrayList<ArbolEneario>();
			this.hijos.add(son);
		}
		/*else
			for(ArbolEneario ar :hijos) {
				ar.agregarHijo(valor, tiponodo);
			}*/
		
	}
	
	public ArbolEneario(String titulo) {
		this.valor=titulo;
		this.tiponodo=TipoNodo.TITULO;
		
		
		
	}
	
	public void setearTitulo(String titulo) {
		this.valor=titulo;
	}
	
	public ArbolEneario(String valor,TipoNodo tiponodo) {
		this.valor=valor;
		this.tiponodo=tiponodo;
		
		
	}
	
	private void asignarValores(String valor,TipoNodo tiponodo) {
		this.valor=valor;
		this.tiponodo=tiponodo;
	}
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[Nodo: " +this.tiponodo.toString()+"; Valor: "+this.valor+"]";
	}

	public ArrayList<String> imprimir(ArbolEneario x) {
		HashSet<String>resultado=new HashSet<String>();
		resultado.add(x.toString());
		for(ArbolEneario ar:x.hijos) {
			resultado.addAll(imprimir(ar));
		}
		ArrayList<String>resultadox=new ArrayList<String>();
		resultadox.addAll(resultado);
		return resultadox;
		

			
	}
	
	public HashSet<ArbolEneario> devolverLista() {
		HashSet<ArbolEneario>resultado=new HashSet<ArbolEneario>();
		resultado.add(this);
		if(hijos!=null)
		for(ArbolEneario ar:hijos) {
			resultado.addAll(ar.devolverLista());
		}
		return resultado;
		

			
	}
	
	private boolean verificarCompatibilidad(TipoNodo padre,TipoNodo hijo) {
		String nodoPadre=padre.name();
		String nodoHijo=hijo.name();
		if(nodoPadre=="TITULO"&&(nodoHijo=="METADATO"||nodoHijo=="RESUMEN"||nodoHijo=="CAPITULO"))
			return true;
		else {
			if(nodoPadre=="METADATO"&&(nodoHijo=="AUTOR"||nodoHijo=="EDITORIAL"||nodoHijo=="PALABRA_CLAVE"||nodoHijo=="FECHA"))
				return true;
			else{
				if(nodoPadre=="RESUMEN"&&(nodoHijo=="PARRAFO"))
					return true;
				else {
					if(nodoPadre=="CAPITULO"&&(nodoHijo=="SECCION"||nodoHijo=="METADATO_CAPITULO"))
						return true;
					else {
						if(nodoPadre=="SECCION"&&nodoHijo=="PARRAFO")
							return true;
						else {
							if(nodoPadre=="METADATO_CAPITULO"&&(nodoHijo=="SITIO_WEB"||nodoHijo=="SITIO_WEB_EJERCICIO"||nodoHijo=="PALABRA_CLAVE"))
								return true;
							else
								return false;
						}
					}
				}
			}
			
		}	
		
	}
	
	public boolean buscarArbol(String valor,TipoNodo nodo) {
		for(ArbolEneario n:this.devolverLista()) {
			if(n.valor.equals(valor)&&n.tiponodo.equals(nodo)) {
				return true;
			}
		}
		return false;
		
	}
}
